<?php
function call($controller, $action) 
{
 session_start();
    require_once('/App/Controllers/' . $controller . 'Controller.php');
     
    switch ($controller) 
    {
        case 'Index':
            $controller = new IndexController();
            break;
        case 'Register':
            $controller = new RegisterController();
            require_once('Public/Register.php');
            break;

        case 'Admin':
            $controller = new AdminController();
            break;
        case 'Client':
            $controller = new ClientController();
            break;
        case 'Manager':
            $controller = new ManagerController();
            break;
        default : //default page becomes ERROR 404 PAGE NOT FOUND
            $controller = new ErrorController();
            require_once('Public/Error.php');
            break;
    }
//This start more of a role sesion for every controller
   
    $controller->{ $action }();
}

// we're adding an entry for the new controller and its actions
$controllers = array('Index' => array('home','about','contact','login','register','opentenders'),'Admin' => array('home','viewprofile','viewtender','viewapplication','advertisetender', 'updatetender', 'recordpayment','logout'), 'Client' => array('home','viewprofile','makeapplication','viewtender', 'viewapplication','cancelapplication','logout'),'Manager' => array('home','viewapplicationreport','viewpaymentreport','addCompany','addAdmin', 'assigntender','approvetender','logout'));


if (array_key_exists($controller, $controllers)) 
{
    if (in_array($action, $controllers[$controller])) 
    {
        call($controller, $action);
    }
    else 
        {
        call('Index', 'index');
        }
} 
else 
    {
    call('Error', 'error');
    }
    ?>