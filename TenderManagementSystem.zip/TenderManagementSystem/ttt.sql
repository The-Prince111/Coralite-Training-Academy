/*
SQLyog Community Edition- MySQL GUI v5.22a
Host - 5.1.41 : Database - tender_database
*********************************************************************
Server version : 5.1.41
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `tender_database`;

USE `tender_database`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `tblapplicationdoc` */

DROP TABLE IF EXISTS `tblapplicationdoc`;

CREATE TABLE `tblapplicationdoc` (
  `applicationDoc_no` int(8) NOT NULL AUTO_INCREMENT,
  `applicationDoc_document` varchar(200) DEFAULT NULL,
  `application_no` int(7) unsigned DEFAULT NULL,
  PRIMARY KEY (`applicationDoc_no`),
  KEY `FK_tblapplicationdoc_ref_tenderapplication` (`application_no`),
  CONSTRAINT `FK_tblapplicationdoc_ref_tenderapplication` FOREIGN KEY (`application_no`) REFERENCES `tbltenderapplication` (`application_no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

/*Data for the table `tblapplicationdoc` */

insert  into `tblapplicationdoc`(`applicationDoc_no`,`applicationDoc_document`,`application_no`) values (1,NULL,127),(2,NULL,125),(3,NULL,126),(4,NULL,123),(5,NULL,124),(6,'~\\AppFiles\\Resources.pri',162);

/*Table structure for table `tblcategory` */

DROP TABLE IF EXISTS `tblcategory`;

CREATE TABLE `tblcategory` (
  `category_id` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `category_desc` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

/*Data for the table `tblcategory` */

insert  into `tblcategory`(`category_id`,`category_desc`) values (001,'Accounting'),(002,'Agriculture'),(003,'Air Conditioning'),(004,'Catering Services'),(005,'Cleaning Services'),(006,'Computers'),(007,'Electrical Engineering'),(008,'Vehicle Repairs'),(009,'Water Works'),(010,'Waste Removal');

/*Table structure for table `tblcompany` */

DROP TABLE IF EXISTS `tblcompany`;

CREATE TABLE `tblcompany` (
  `company_no` int(3) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `company_name` varchar(70) DEFAULT NULL,
  `company_type` varchar(50) DEFAULT NULL,
  `company_addressStreet` varchar(50) DEFAULT NULL,
  `company_addressTown` varchar(30) DEFAULT NULL,
  `company_province` varchar(30) DEFAULT NULL,
  `company_addressCode` int(5) DEFAULT NULL,
  PRIMARY KEY (`company_no`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `tblcompany` */

insert  into `tblcompany`(`company_no`,`company_name`,`company_type`,`company_addressStreet`,`company_addressTown`,`company_province`,`company_addressCode`) values (000,NULL,NULL,NULL,NULL,NULL,NULL),(002,'Mabala and Sons','Closed corpoation','1041b greenside','Pankop','Mpumalanga',1414),(003,'Brothers in Construction','General partnership','cnr Louise @ woltemade st','Witbank','Mpumalanga',1035),(004,'Leboneng sisters','Limited partnership','12 Leboneng ','Temba','North west',1407),(005,'Nkgwete IT solutions','Corporation ','17 Wandervald','Pretoria','Gauteng',1111),(006,'Potgieter constructions','Closed corporation ','12 katlegong','Mogogelo','Limpopo',1679),(007,NULL,NULL,NULL,NULL,NULL,NULL),(008,'Test company','Closed Corporation','jakaroo','Witbank','Mpumalanga',1234);

/*Table structure for table `tblpayment` */

DROP TABLE IF EXISTS `tblpayment`;

CREATE TABLE `tblpayment` (
  `payment_no` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` double(8,2) DEFAULT NULL,
  `payment_receipt` varchar(100) DEFAULT NULL,
  `user_no` int(6) unsigned DEFAULT NULL,
  `application_no` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`payment_no`),
  KEY `FK_tblpayment_ref_tbluser` (`user_no`),
  KEY `FK_tblpayment_ref_tenderapplication` (`application_no`),
  CONSTRAINT `FK_tblpayment_ref_tbluser` FOREIGN KEY (`user_no`) REFERENCES `tbluser` (`user_no`),
  CONSTRAINT `FK_tblpayment_ref_tenderapplication` FOREIGN KEY (`application_no`) REFERENCES `tbltenderapplication` (`application_no`)
) ENGINE=InnoDB AUTO_INCREMENT=759 DEFAULT CHARSET=latin1;

/*Data for the table `tblpayment` */

insert  into `tblpayment`(`payment_no`,`payment_date`,`payment_amount`,`payment_receipt`,`user_no`,`application_no`) values (00000343,'2018-06-10 12:30:00',130000.00,NULL,114,127),(00000434,'2018-02-11 11:30:00',120000.00,NULL,111,125),(00000495,'2018-03-11 12:00:00',100000.00,NULL,112,123),(00000687,'2017-03-09 11:00:00',90000.00,NULL,113,124),(00000758,'2018-03-10 12:00:00',290999.00,NULL,115,126);

/*Table structure for table `tbltender` */

DROP TABLE IF EXISTS `tbltender`;

CREATE TABLE `tbltender` (
  `tender_no` int(7) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `tender_region` varchar(30) DEFAULT NULL,
  `tender_description` varchar(200) DEFAULT NULL,
  `tender_datePosted` datetime DEFAULT NULL,
  `tender_closingDate` datetime DEFAULT NULL,
  `tender_status` varchar(20) DEFAULT NULL,
  `tender_amount` double(8,2) DEFAULT NULL,
  `tender_detailsDoc` varchar(100) DEFAULT NULL,
  `tender_view` int(5) DEFAULT NULL,
  `user_no` int(6) unsigned DEFAULT NULL,
  `category_id` int(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`tender_no`),
  KEY `FK_tbltender_ref_tbluser` (`user_no`),
  KEY `FK_tbltender_ref_tblcategory` (`category_id`),
  CONSTRAINT `FK_tbltender_ref_tblcategory` FOREIGN KEY (`category_id`) REFERENCES `tblcategory` (`category_id`),
  CONSTRAINT `FK_tbltender_ref_tbluser` FOREIGN KEY (`user_no`) REFERENCES `tbluser` (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=latin1;

/*Data for the table `tbltender` */

insert  into `tbltender`(`tender_no`,`tender_region`,`tender_description`,`tender_datePosted`,`tender_closingDate`,`tender_status`,`tender_amount`,`tender_detailsDoc`,`tender_view`,`user_no`,`category_id`) values (0000444,'Mpumalanga','Supply of manure and 100 labourers for farming.','2018-09-23 10:30:00','2021-09-23 10:00:00','Not Approved',NULL,NULL,89,115,6),(0000666,'North west','Cleaners needed to clean the area around the jubilee hospital','2018-04-19 10:00:00','2019-01-30 09:30:00','Approved',NULL,NULL,29,113,7),(0000777,'Mpumalanga','Supply of water for building an old age home at Witbank','2018-09-09 10:00:00','2019-10-10 10:30:00','Not Approved',NULL,NULL,189,112,3),(0000888,'Limpopo','60 air conditioners needed for the limpopo private hospital','2017-01-19 11:30:00','2018-12-01 11:00:00','Not Approved',NULL,NULL,900,111,3),(0000999,'Free state','Supply of Water for the people who has no water tabs','2018-01-29 09:30:00','2020-05-05 12:00:00','Not Approved',NULL,NULL,190,114,4),(0001000,NULL,'Test tender',NULL,NULL,'Approved',NULL,NULL,0,112,2),(0001001,'Gauteng','Test gauteng tenders eeeg','2018-08-16 10:52:02','2018-11-17 00:00:00','Not Approved',NULL,'~\\TenderFiles\\server_tracking_data',0,112,2),(0001002,'Mpumalanga','Mpumalanga test tender','2018-08-16 14:25:14','2018-11-25 00:00:00','Not Approved',NULL,'~\\TenderFiles\\Rad_Studio_XE6_Downloadsversion.ini',0,112,3),(0001007,'Gauteng','KKK','2018-10-16 00:00:00','2020-10-16 00:00:00','Not Approved',0.00,'C:UsersphilaneDesktopverse.txt',0,112,1),(0001008,'Free State','KKK Test','2018-10-17 00:00:00','2020-10-18 00:00:00','Not Approved',0.00,'C:UsersphilaneDocumentsmain.jpg',0,112,6),(0001009,'Free State','KKK Test','2018-10-17 00:00:00','2020-10-18 00:00:00','Not Approved',0.00,'C:UsersphilaneDocumentsmain.jpg',0,112,6),(0001010,'Free State','KKK Test','2018-10-17 00:00:00','2020-10-18 00:00:00','Not Approved',0.00,'C:UsersphilaneDocumentsmain.jpg',0,112,6),(0001011,'Gauteng','new tender','2018-10-17 00:00:00','2019-12-18 00:00:00','Not Approved',0.00,'C:UsersphilaneDocumentsCorrespondence_ Regret.PDF',0,113,4);

/*Table structure for table `tbltenderapplication` */

DROP TABLE IF EXISTS `tbltenderapplication`;

CREATE TABLE `tbltenderapplication` (
  `application_no` int(10) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `application_date` datetime DEFAULT NULL,
  `application_status` varchar(15) DEFAULT 'Not Issued',
  `application_bidDoc` varchar(100) DEFAULT NULL,
  `application_amount` double(8,2) DEFAULT NULL,
  `user_no` int(6) unsigned DEFAULT NULL,
  `tender_no` int(7) unsigned DEFAULT NULL,
  PRIMARY KEY (`application_no`),
  KEY `FK_tbltenderapplication_ref_tbluser` (`user_no`),
  KEY `FK_tbltenderapplication_tbltender` (`tender_no`),
  CONSTRAINT `FK_tbltenderapplication_ref_tbluser` FOREIGN KEY (`user_no`) REFERENCES `tbluser` (`user_no`),
  CONSTRAINT `FK_tbltenderapplication_tbltender` FOREIGN KEY (`tender_no`) REFERENCES `tbltender` (`tender_no`)
) ENGINE=InnoDB AUTO_INCREMENT=170 DEFAULT CHARSET=latin1;

/*Data for the table `tbltenderapplication` */

insert  into `tbltenderapplication`(`application_no`,`application_date`,`application_status`,`application_bidDoc`,`application_amount`,`user_no`,`tender_no`) values (0000000123,'2018-03-10 12:00:00','Not Issued',NULL,NULL,112,777),(0000000124,'2017-08-19 10:00:00','Issued',NULL,NULL,113,666),(0000000125,'2018-05-18 11:30:00','Not Issued',NULL,NULL,114,444),(0000000126,'2017-12-12 09:00:00','Issued',NULL,NULL,115,888),(0000000127,'2018-02-10 08:30:00','Issued',NULL,NULL,111,999),(0000000128,'2018-08-16 11:46:49','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,116,1001),(0000000129,'2018-08-16 11:48:00','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,116,1001),(0000000130,'2018-08-16 11:48:03','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,116,1001),(0000000131,'2018-08-16 11:48:18','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,111,1001),(0000000132,'2018-08-16 11:48:31','Cancelled','~\\AppFiles\\server_tracking_data',5050.80,111,1001),(0000000133,'2018-08-16 11:48:43','Cancelled','~\\AppFiles\\server_tracking_data',5050.80,111,1001),(0000000134,'2018-08-16 12:05:25','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000135,'2018-08-16 12:05:32','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000136,'2018-08-16 12:05:35','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000137,'2018-08-16 12:05:38','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000138,'2018-08-16 12:05:41','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000139,'2018-08-16 12:05:44','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000140,'2018-08-16 12:05:48','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000141,'2018-08-16 12:05:51','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000142,'2018-08-16 12:05:54','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000143,'2018-08-16 12:05:57','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000144,'2018-08-16 12:06:00','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000145,'2018-08-16 12:06:04','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000146,'2018-08-16 12:06:07','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000147,'2018-08-16 12:06:10','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000148,'2018-08-16 12:06:13','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000149,'2018-08-16 12:06:17','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000150,'2018-08-16 12:06:20','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000151,'2018-08-16 12:06:49','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000152,'2018-08-16 12:06:55','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000153,'2018-08-16 12:06:58','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000154,'2018-08-16 12:07:02','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000155,'2018-08-16 12:07:05','Not Issued','~\\AppFiles\\server_tracking_data',5050.80,NULL,1001),(0000000156,'2018-08-16 12:07:27','Not Issued','~\\AppFiles\\installer_prefs.json.backup',30000.00,NULL,1000),(0000000157,'2018-08-16 12:10:18','Not Issued','~\\AppFiles\\installer_prefs.json.backup',30000.00,NULL,1000),(0000000158,'2018-08-16 12:10:20','Not Issued','~\\AppFiles\\installer_prefs.json.backup',30000.00,NULL,1000),(0000000159,'2018-08-16 12:10:49','Not Issued','~\\AppFiles\\pref_default_overrides',8000.89,NULL,1000),(0000000160,'2018-08-16 12:12:39','Not Issued','~\\AppFiles\\pref_default_overrides',8000.89,NULL,1000),(0000000161,'2018-08-16 12:12:43','Not Issued','~\\AppFiles\\pref_default_overrides',8000.89,NULL,1000),(0000000162,'2018-08-16 12:14:43','Not Issued','~\\AppFiles\\server_tracking_data',7000.00,NULL,1001),(0000000167,'2018-10-18 00:00:00','Not Issued','C:UsersphilaneDocumentsTender Class.jpg',5000.00,114,444),(0000000168,'2018-10-18 00:00:00','Cancelled','C:UsersphilaneDocumentsTender Class.jpg',5000.00,114,444),(0000000169,'2018-10-18 00:00:00','Cancelled','C:UsersphilaneDocumentsTender Class.jpg',5000.00,114,444);

/*Table structure for table `tbluser` */

DROP TABLE IF EXISTS `tbluser`;

CREATE TABLE `tbluser` (
  `user_no` int(6) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `user_username` varchar(50) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `user_surname` varchar(30) DEFAULT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `user_gender` varchar(6) DEFAULT NULL,
  `user_idNr` varchar(13) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_cellNr` varchar(10) DEFAULT NULL,
  `user_tellNr` varchar(10) DEFAULT NULL,
  `user_role` varchar(15) DEFAULT NULL,
  `company_no` int(3) DEFAULT NULL,
  PRIMARY KEY (`user_no`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=latin1;

/*Data for the table `tbluser` */

insert  into `tbluser`(`user_no`,`user_username`,`user_password`,`user_surname`,`user_name`,`user_gender`,`user_idNr`,`user_email`,`user_cellNr`,`user_tellNr`,`user_role`,`company_no`) values (000111,'Siphoo','12345','Nkosi','Siphosethuu','Male','9506110990088','siphosethu@gmail.com','0714606959','0122222554','Client',NULL),(000112,'Clement','12345','Khoza','Clement','Male','9806110990098','co@gmail.com','0764545065','0163254158','Admin',7),(000113,'Berry','12345','Juiece','Kgothatso ','Female','9006110336985','kgothi@gmail.com','0774545065','0163254158','Admin',2),(000114,'Lion','12345','','','','id','','0764545065','0163254158','Client',NULL),(000115,'Sipho','12345','','','','id','','0764545065','0163254158','Client',NULL),(000116,'Sipho','12345','','','','id','','0764545065','0163254158','Client',NULL),(000117,'Sipho','12345','','','','id','','0764545065','0163254158','Client',NULL),(000120,'Sipho','12345','','','','id','','0764545065','0163254158','Client',7),(000121,'Sipho','12345','','','','id','','0764545065','0163254158','Client',8),(000122,'Sipho','12345','','','','id','','0764545065','0163254158','Client',8),(000123,'Sipho','12345','','','','id','','0764545065','0163254158','Client',NULL),(000124,'Sipho','12345','','','','id','','0764545065','0163254158','Client',6),(000125,'Sipho','12345','','','','id','','0764545065','0163254158','Client',8),(000126,'Sipho','12345','','','','id','','0764545065','0163254158','Client',3),(000127,'Nyzo','12345','Nkuna','Nyzo Sboniso','Male','9606110990098','nyzo@hotmail','0764545065','0163254158','Manager',6),(000131,'Muzi','Muzi@123','Ngozo','hlayixx','male','656565656','co@gmail.com','0846253525','0134568588','Admin',0);

/* Procedure structure for procedure `addTender` */

/*!50003 DROP PROCEDURE IF EXISTS  `addTender` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `addTender`(
 IN ptregion VARCHAR(30),
 IN ptdesc VARCHAR(200),
 IN pcdate DATE,
 IN ptdoc VARCHAR(100),
 IN pusername VARCHAR(30),
 IN pcategory INT(3)
 )
BEGIN
 DECLARE v_user_no INT(5);
 SELECT user_no INTO v_user_no FROM tbluser WHERE user_username = pusername;
 INSERT INTO tbltender(tender_region,tender_description,tender_datePosted,tender_closingDate,tender_status,tender_detailsDoc,tender_view,user_no,category_id)
 VALUES(ptregion,ptdesc,now(),pcdate,'Approved',ptdoc,0,v_user_no,pcategory);
 END */$$
DELIMITER ;

/* Procedure structure for procedure `applyTender` */

/*!50003 DROP PROCEDURE IF EXISTS  `applyTender` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `applyTender`(
 IN pbiddoc VARCHAR(100),
 IN pappamount DOUBLE(8,2),
 IN pusername VARCHAR(30),
 IN ptenno INT(5)
 )
BEGIN
 DECLARE v_user_no INT(5);
 	 SELECT user_no INTO v_user_no FROM tbluser WHERE user_username = pusername;
 INSERT INTO tbltenderapplication(application_date,application_bidDoc,application_amount,user_no,tender_no)
 VALUES(now(),pbiddoc,pappamount,v_user_no,ptenno);
 END */$$
DELIMITER ;

/* Procedure structure for procedure `makePayment` */

/*!50003 DROP PROCEDURE IF EXISTS  `makePayment` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `makePayment`(
 IN pamount DOUBLE(8,2),
 IN preceipt VARCHAR(100),
 IN pusername VARCHAR(30),
 IN pappno INT(5)
 )
BEGIN
 DECLARE v_user_no int(5);
 SELECT user_no INTO v_user_no FROM tbluser WHERE user_username = pusername;
 INSERT INTO tblpayment(payment_date,payment_amount,payment_receipt,user_no,application_no)
 VALUES(NOW(),pamount,preceipt,v_user_no,pappno);
 END */$$
DELIMITER ;

/* Procedure structure for procedure `registerManager` */

/*!50003 DROP PROCEDURE IF EXISTS  `registerManager` */;

DELIMITER $$

/*!50003 CREATE DEFINER=`root`@`localhost` PROCEDURE `registerManager`(
 IN mUsername VARCHAR(30),
 IN mSName VARCHAR(30),
 IN mName VARCHAR(30),
 IN mIDNr VARCHAR(13),
 IN mEmail VARCHAR(80),
 IN mCell VARCHAR(13),
 IN mTell VARCHAR(13),
 IN cName VARCHAR(50),
 IN cType VARCHAR(30),
 IN cStreet VARCHAR(50),
 IN cTown VARCHAR(80),
 IN cProvince VARCHAR(30),
 IN cCode VARCHAR(4)
 )
BEGIN
 DECLARE v_compID INT(3);
 INSERT INTO tblcompany(company_name,company_type,company_addressStreet,company_addressTown,company_province,company_addressCode)
 VALUES(cName,cType,cStreet,cTown,cProvince,cCode);
 SELECT MAX(company_no) INTO v_compID FROM tblcompany;
 INSERT INTO tbluser(user_username,user_surname,user_name,user_idNr,user_email,user_cellNr,user_tellNr,user_role,company_no)
 VALUES(mUsername,mSName,mName,mIDNr,mEmail,mCell,mTell,'Manager',v_compID);
 END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
