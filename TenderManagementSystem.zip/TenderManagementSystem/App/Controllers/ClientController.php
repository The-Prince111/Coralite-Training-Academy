<?php
require_once 'App/Models/Render.php';
require_once 'App/Models/Client.php';
require_once 'App/Models/Tender.php';
require_once 'App/Models/User.php';
require_once 'App/Models/Application.php';
require_once 'App/Models/clientSummary.php';
require_once 'App/Models/tenSummary.php';

class ClientController
{
    public function client()
    {
    }
    public function home()
    {
        $username = $_SESSION['user_username'];
        $password = $_SESSION['user_password'];
        $userNames = clientSummary::getUserFullnames($username,$password);
        $clientApps = clientSummary::totUserApps($username);
        $clientApprovedApps = clientSummary::clientApprovedApps($username);
        $clientPendingApps = clientSummary::clientPendingApps($username);
        $totOpenTenders = clientSummary::totOpenTenders();
        $totExpTenders = clientSummary::totClosedTenders();
        require_once 'App/Views/Client/clientSummary.php';
        
    }
    
    public function viewprofile()
    {
        	$username = $_SESSION['user_username'];
                $password = $_SESSION['user_password'];
                $company = $_SESSION['company_no'];
                $role = $_SESSION['user_role'];
               
                if(isset($_POST['btnUpdate']))
                {
                    $userprofile=Client::viewprofile($username,$password);
                    require_once 'App/Views/Client/updateProfile.php';
                }
                else if(isset($_POST['btnHome']))
                {
                    Render::render('CHome');
                } 
                else if (isset($_POST['btnSaveChanges'])) 
                {
                     $pUsername = $_POST["username"];
                     $pPassword = $_POST["password"];
                     $pSurname = $_POST["surname"];
                     $pFullnames = $_POST["name"];
                     $pGender = $_POST["gender"];
                     $pIDNo = $_POST["idNo"];
                     $pEmail = $_POST["email"];
                     $pCell = $_POST["cell"];
                     $pTell = $_POST["tell"];
                     $pRole = $_POST["role"];
                Client::updateprofile($pUsername,$pPassword,$pSurname,$pFullnames,$pGender,$pIDNo,$pEmail,$pCell,$pTell,$pRole,$username);
                 
                        //Refresh
                         $userprofile=Client::viewprofile($username,$password);
                       require_once 'App/Views/Client/Profile.php';
		}
                else
                {
                $userprofile=Client::viewprofile($username,$password);
                require_once 'App/Views/Client/Profile.php';
                }


    }
    
    public function viewtender()
    {


         if (isset($_POST['btnApply'])) 
         {
             $ten_no = $_POST["tenNo"];
             $ten_desc = $_POST["tenDesc"];
                $tenderNo = Tender::gettendert($ten_no);
                require_once 'App/Views/Client/ApplyTender.php'; 
         }
         else if(isset($_POST['btnApplyTender']))
             {
               $username = $_SESSION['user_username'];
                $password = $_SESSION['user_password'];
                $pTID = $_POST["tenderNumber"];
                $userNo  = User::getUserNo($username, $password);
                $pUNO = $userNo->rUserNo;
                $pTender_amount = $_POST["amount"];
                $pTender_bid = $_POST["bid"];
                   if(!is_numeric($pTender_amount))
                   {
                                    $ten_no = $_POST["tenNo"];
             $ten_desc = $_POST["tenDesc"];
                $tenderNo = Tender::gettendert($ten_no);
                       require_once 'App/Views/Client/ApplyTender.php'; 
                       
                       $error_found = "invalid amount";
                       echo "<p style='color:red'>$error_found</p>";
                      exit();
                   }
             Application::applytender($pTender_bid,$pTender_amount,$pUNO,$pTID);
             //Refresh
             $uname = $_SESSION['user_username'];
             $userApplications=Application::viewapplication($uname);
                require_once 'App/Views/Client/viewApplication.php';
             }
         else if(isset($_POST['btnHome']))
         {
             Render::render('CHome');
         }
        else if (isset($_POST['btnCancel'])) 
         {
             $username = $_SESSION['user_username'];
             $password = $_SESSION['user_password'];
             $appNumber = $_POST["appNo"];
             $userNo = User::getUserNo($username, $password);
             $uNo = $userNo->rUserNo;
            // echo 'usernumber + appNo = '.$uNo.' + '.$appNumber.' ';
             Application::cancelapplication($uNo,$appNumber);
             
             //refresh
             $uname = $_SESSION['user_username'];
          $userApplications=Application::viewapplication($uname);
          require_once 'App/Views/Client/viewApplication.php';
         }
         else
         {
             if(isset($_POST[province]))
             {
                 $prov =$_POST['province'];
                  $usertenders= Tender::tenderP($prov);
                   require_once 'App/Views/Client/viewTender.php';
             }
             else
             {
          $usertenders=Tender::viewtenders();
          require_once 'App/Views/Client/viewTender.php';
             }
         }
    }
    
    public function viewapplication()
    {
        
         if (isset($_POST['btnCancel'])) 
         {
             $username = $_SESSION['user_username'];
             $password = $_SESSION['user_password'];
             $appNumber = $_POST["appNo"];
             $userNo = User::getUserNo($username, $password);
             $uNo = $userNo->rUserNo;
             Application::cancelapplication($uNo,$appNumber);
             
             //refresh
             $uname = $_SESSION['user_username'];
      $userApplications=Application::viewapplication($uname);
        require_once 'App/Views/Client/viewApplication.php';
         }
           else if(isset($_POST['btnHome']))
             {
                 Render::render('CHome');
             }
             else
             {
                 $uname = $_SESSION['user_username'];
                $userApplications=Application::viewapplication($uname);
                  require_once 'App/Views/Client/viewApplication.php';
             }

        
    }

}

?>