<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require_once 'App/Models/User.php';
require_once 'App/Models/Error.php';
require_once 'Config/Routes.php';

class ErrorController
{
   public function error()
   {
       require_once 'Public/Error.php';
   }

}

?>
