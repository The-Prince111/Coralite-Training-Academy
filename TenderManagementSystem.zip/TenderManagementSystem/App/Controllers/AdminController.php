<?php
require_once 'App/Models/Render.php';
require_once 'App/Models/Admin.php';
require_once 'App/Models/Tender.php';
require_once 'App/Models/Application.php';
require_once 'App/Models/Category.php';

class AdminController
{
    public  $categories;
    public function home()
    {
        $this->view->message = 'Welcome to Admin portal on tender management system';
        Render::render('AHome');
    }
    public function viewprofile()
    {
               $username = $_SESSION['user_username'];
                $password = $_SESSION['user_password'];
                $company = $_SESSION['company_no'];
                $role = $_SESSION['user_role'];
                
                if(isset($_POST['btnUpdate']))
                {
                 $adminprofile=Admin::viewprofile($username,$password);
                 require_once 'App/Views/Admin/updateProfile.php';
                }
                else if(isset($_POST['btnHome']))
                {
                    Render::render('AHome');
                }
                else if (isset($_POST['btnSaveCanges'])) 
                {
                     $pUsername = $_POST["username"];
                     $pPassword = $_POST["password"];
                     $pSurname = $_POST["surname"];
                     $pFullnames = $_POST["name"];
                     $pGender = $_POST["gender"];
                     $pIDNo = $_POST["idNo"];
                     $pEmail = $_POST["email"];
                     $pCell = $_POST["cell"];
                     $pTell = $_POST["tell"];
                     $pRole = $_POST["role"];
                Admin::updateprofile($pUsername,$pPassword,$pSurname,$pFullnames,$pGender,$pIDNo,$pEmail,$pCell,$pTell,$pRole,$username);
		
                //Refresh
                 $adminprofile=Admin::viewprofile($username,$password);
                 require_once 'App/Views/Admin/Profile.php';
                } 
                else
                {
                  $adminprofile=Admin::viewprofile($username,$password);
                 require_once 'App/Views/Admin/Profile.php';
                }
              


    }
    public function viewapplication()
    {

        if(isset($_POST['btnHome']))
             {
                 Render::render('AHome');
             }
             else
             {
           $uname = $_SESSION['user_username'];
         $company = $_SESSION['company_no'];
         
        $adminApplications=Application::viewapplication($uname,$company); 
             }
        if(!$adminApplications)
        {
            echo 'No Application Made this far';
        }
        require_once 'App/Views/Admin/ViewApps.php';
    }
    public function viewtender()
    {
            if(isset($_POST['btnUpdate']))
            {
                
                $tenNumber = $_POST["tenNo"];
                $tencat = Category::getCategory($tenNumber);
                  $company = $_SESSION['company_no'];
                  $admintender= Tender::gettender($company,$tenNumber);
                  $categories = Category::getCategories();
                  require_once 'App/Views/Admin/updateTender.php';
            }
            else if(isset($_POST['btnSaveChanges']))
            {
                $ptenNo = $_POST["tenNo"];
                $pRegion = $_POST["province"];
                $pTender_description = $_POST["description"];
                $pTender_closingDate = $_POST["closingDate"];
                $pCategory_id = $_POST["category"];
                
                Tender::updatetender($pRegion,$pTender_description,$pTender_closingDate,$pCategory_id,$ptenNo);
                
             //Refresh
         $company = $_SESSION['company_no'];
        $admintenders= Tender::viewtender($company);
        require_once 'App/Views/Admin/ViewTenders.php';
        
            }
            else  if(isset($_POST['btnHome']))
             {
                 Render::render('AHome');
             }
 else {
         $company = $_SESSION['company_no'];
         echo "Am Here";
        $admintenders= Tender::viewtender($company);
        require_once 'App/Views/Admin/ViewTenders.php';
 }
    }

    public function advertisetender()
    {
        
          if (isset($_POST['btnAvertiseTender'])) 
          {
                $pRegion = $_POST["province"];
                $pTender_description = $_POST["description"];
                $pTender_closingDate = $_POST["closingDate"];
                $pTender_detailsDoc = $_POST["bid"];
                $pUser_no = $_SESSION['user_no'];
                $pCategory_id = $_POST["category"];
              Tender::advertisetender($pRegion,$pTender_description,$pTender_closingDate,$pTender_detailsDoc,$pUser_no,$pCategory_id) ;
             //Refresh
         $company = $_SESSION['company_no'];
        $admintenders= Tender::viewtender($company);
        require_once 'App/Views/Admin/ViewTenders.php';
          }
          else             if(isset($_POST['btnUpdate']))
            {
                $tenNumber = $_POST["tenNo"];
                  $company = $_SESSION['company_no'];
                  $admintender= Tender::gettender($company,$tenNumber);
                  $categories = Category::getCategories();
                  require_once 'App/Views/Admin/updateTender.php';
            }
          else if(isset($_POST['btnHome']))
             {
                 Render::render('AHome');
             }
             else
             {
             $categories = Category::getCategories();
             require_once 'App/Views/Admin/AdvertiseTender.php';
             }
       
    }
    public function updatetender()
    {
        Tender::updatetender();
    }
    public function makepayment()
    {
        Payment::makePayment();
    }
    public function recordpayment()
    {
        rPayment::makePayment();
    }
    
}


?>