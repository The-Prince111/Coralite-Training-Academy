<?php
require_once 'App/Models/Render.php';
require_once 'App/Models/Payment.php';
require_once 'App/Models/Tender.php';
require_once 'App/Models/Application.php';
require_once 'App/Models/Category.php';
require_once 'App/Models/appSummary.php';
require_once 'App/Models/tenSummary.php';
require_once 'App/Models/manSummary.php';


class ManagerController
{
     public function home()
    {
        $username = $_SESSION['user_username'];
        $password = $_SESSION['user_password'];
        $totPostedTenders = manSummary::totPostedTenders($username);
        $totOpenTenders = manSummary::totOpenTenders($username);
        echo "open tends '$totOpenTenders' ";
        $totClosedTenders = manSummary::totClosedTenders($username);
        $totApplications = manSummary::totApplications($username);
        $totPayments = manSummary::totPayments($username);
        
        require_once 'App/Views/Manager/manSummary.php';
    }
    public function viewpaymentreport()
    {
             
            if (isset($_POST['mindate']) || isset($_POST['maxdate']))  
            {  
                $min_date = $_POST['mindate'];
                $max_date = $_POST['maxdate'];
                $date_expire = $max_date;

            }
            else
            {
                $minDate = date_create('first day of November 2018');
                $min_date = $minDate->format('Y-m-d');
                $maxDate = date("Y-m-d");
                $max_date = $maxDate; 
            }
  
   $username = $_SESSION['user_username'];
       $totPayments = tenSummary::totPayDate($min_date,$max_date,$username);
          $totAmount = tenSummary::totSumDate($min_date,$max_date,$username);

$date = new DateTime($date_expire);
$now = new DateTime($min_date);
$interval =  $date->diff($now)->format("%Y year(s), %d days %h hours and %i minuts");
require_once 'App/Views/Manager/paySummary.php';

    }
    
    public function assigntender()
    {
             if(isset($_POST['btnHome']))
             {
                 Render::render('MHome');
             }
             else
             if(isset($_POST['btnAssign']))
                 {
                      Tender::assignTender();
                 }
             else
             {
                      $company = $_SESSION['company_no'];
                         $manApplications=Application::viewapps($company);
                            require_once 'App/Views/Manager/AssignTender.php';
                         
             }
        if(!$manApplications)
        {
            echo 'Assign Tender not open yet';
        }
       
    }
    public function approvetender()
    {
       // $categories = Category::getCategories();
             if(isset($_POST['btnHome']))
             {
                Render::render('MHome');
             }
             else if (isset($_POST['btnApprove'])) 
             {
                 $_SESSION['ten_no'] = $ten_no;
                 $_SESSION['ten_desc'] = $ten_desc;
                  Tender::approveTender();
             }
             else
             { 
               $comp = $_SESSION['company_no'];
                 $categories = Category::getCategories();
                      $mantenders=Tender::viewtender($comp);
                          require_once 'App/Views/Manager/ApproveTender.php';
             }
    }
   public function viewapplicationreport()
    {
         
          
            if (isset($_POST['mindate']) || isset($_POST['maxdate']))  
            {  
                $min_date = $_POST['mindate'];
                $max_date = $_POST['maxdate'];
            }
            else
            {
                $minDate = date_create('first day of November 2018');
                $min_date = $minDate->format('Y-m-d');
                $maxDate = date("Y-m-d");
                $max_date = $maxDate; 
            }
  
   $username = $_SESSION['user_username'];
       $totDate = tenSummary::tenSumDate($min_date,$max_date,$username);
          $totApps = appSummary::appSumDate($min_date,$max_date,$username);
          $date = new DateTime($date_expire);
$now = new DateTime($min_date);
$interval =  $date->diff($now)->format("%Y year(s), %d days %h hours and %i minuts");
 require_once 'App/Views/Manager/appSummary.php';

    }
   /* public function addAdmin()
    {

    }
    public function addCompany()
    {

    } */
    
}

?>