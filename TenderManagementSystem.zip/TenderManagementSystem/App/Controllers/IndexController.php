<?php
require_once 'App/Models/Render.php';
require_once 'App/Models/User.php';;
require_once 'App/Models/Client.php';
require_once 'App/Models/Tender.php';
require_once 'App/Models/Category.php';
require_once 'App/Models/Company.php';
require_once 'App/Models/Admin.php';

class IndexController
{
    
    public function __construct() 
      {
        
      }

     public function index()
    {
        Render::render('Home');
    }
    public function about()
    {
        Render::render('About');
    }
    public function contact()
    {
        Render::render('Contact');
    }
    public function  logout()
    {
     $_SESSION = array(); //destroy all of the session variables
 /*   if (ini_get("session.use_cookies")) 
    {
     $params = session_get_cookie_params();
       setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    ); 
    } */
    session_destroy();
         Render::render('Home');
    }
    public function opentenders()
    {
                
        $categories = Category::getCategories();
            //evaluates button clicks because something must happen when each button is pressed
             if(isset($_POST['btnHome']))
             {
                Render::render('Home');
             }
             else if (isset($_POST['btnApply'])) 
             {
                 $ten_no = $_POST["tenNo"];
                 $ten_desc = $_POST["tenDesc"];
                 $_SESSION['ten_no'] = $ten_no;
                 $_SESSION['ten_desc'] = $ten_desc;
                 Render::render('Login'); 
             }
             else if(isset($_POST['btnNew']))
             {
                 Render::render('Register');
             }
             else if(isset($_POST['btnLogin']))
             {
                 $this->login();
             }
            else if(isset($_POST['btnAll']))
             {
                   $categories = Category::getCategories();
                      $filteredtenders=Tender::viewtenders();
                          require_once 'Public/ViewOpenTenders.php';
            }
              if(isset($_POST['closingDate']))
             {
                 $date =$_POST['closingDate'];
                  $filteredtenders= Tender::tenderD($date);
                   require_once 'Public/ViewOpenTenders.php';
             }
             else
             {

                   $categories = Category::getCategories();
                      $filteredtenders=Tender::viewtenders();
                          require_once 'Public/ViewOpenTenders.php';
                 
             }
    }
    public  function login()
    {
       // Render::render('Login');
        if(isset($_POST['btnLogin']))
        {
            $username = $_POST["username"];
            $password = $_POST["password"];
        
        
        $user = User::getUser($username,$password);   // object with a lot of info
        }
          else if(isset($_POST['btnHome']))
          {
              Render::render('Home');
              
          }
          else if(isset($_POST['btnNew']))
          {
              Render::render('Register');
              
          }
        if($user)
        { 
         $_SESSION['user_username'] =  $user->rUsername;
         $_SESSION['user_password'] =  $user->rPassword;
         $_SESSION['user_role'] = $user->rRole;
         $_SESSION['user_no'] = $user->rUserNo;
         $_SESSION['company_no'] = $user->rCompany;
         
         if($user->rRole == "Admin")
        {
            Render::render('AHome');
        }
        else if($user->rRole == "Client")
        {
            Render::render('CHome');
            
        }
        else if($user->rRole == "Manager")
        {
            Render::render('MHome');
        }
        }
        else if(!$user)
        {
            Render::render('Login');
            $error = "Invalid Login Details";
        }
        if($error)
        {
        $error_found = $error;
        }
        else
        {
         $error_found = ""; 
        }
        echo"$error_found";
         
    }
     public function register()
    {
         
        if(isset($_POST['btnRegister']))
        {
            $pUsername = $_POST["username"];
            $pPassword = $_POST["password"];
            $pCPassword = $_POST["confirmpassword"];
            $pSurname = $_POST["surname"];
            $pFullnames = $_POST["fullname"];
            $pGender = $_POST["gender"];
            $pIDNo = $_POST["idNo"];
            $pEmail = $_POST["email"];
            $pCell = $_POST["cell"];
            $pTell = $_POST["tell"];
            $pRole = $_POST["role"];
            if(!strcmp($pPassword, $pCPassword) == 0)
            {
               $error = "Password Does not match";
              // exit();
            }
             if(strlen($pCell) != 10)
            {
           // alert('Cell No. must have 10 charecters');
            $error = "Cell No. must be 10 charecters long";
           // exit();
            }
             if(strlen($pTell) > 0)
            {
                if(strlen($pTell) != 10)
                {
                //alert('Tell No. must have 10 charecters');
                $error = "Tell No. must be 10 charecters long";
              //  exit();
                }
                
            }
             if(strlen($pIDNo) != 13)
            {
                //alert('ID No. must have 10 charecters');
                $error = "ID No. must be 13 charecters long";
               // exit();
            }
            if(strlen($pEmail) > 0)
            {
                $dot = strrpos($pEmail, '.');
             if($dot===false) {
        
                      //alert('Invalid email');  
                     $error = "Invalid email address";
                //  exit();
                   }
            }
            
         if($error)
        {
        Render::render('Register');
        $error_found = $error;
        echo "<p style='color:red'>$error_found</p>";
        }
        else
        {
            if($pRole == "Client")
           {
                User::addUser($pUsername,$pPassword,$pSurname,$pFullnames,$pGender,$pIDNo,$pEmail,$pCell,$pTell,$pRole);
                Render::render('Home');
           }
           else if($pRole == "Manager")
           {
               User::addUser($pUsername,$pPassword,$pSurname,$pFullnames,$pGender,$pIDNo,$pEmail,$pCell,$pTell,$pRole);
               require_once 'App/Views/Manager/AddCompany.php';
               $_SESSION['manager_username'] = $pUsername;
           }
        }
        
        }
        else
        if(isset($_POST['btnAddCompany']))
        {
            $cmanager = $_SESSION['manager_username'];
            $ccopmname = $_POST["copmname"];
            $ccomptype = $_POST["comptype"];
            $ccompprovince = $_POST["compprovince"];
            $ccomptown = $_POST["comptown"];
            $ccompstreet = $_POST["compstreet"];
            $ccompcode = $_POST["compcode"];
            Company::addCompany($ccopmname,$ccomptype,$ccompprovince,$ccomptown,$ccompstreet,$ccompcode,$cmanager);
            require_once 'App/Views/Manager/AddAdmin.php';
        }
        else
        if(isset($_POST['btnAddAdmin']))
        {
            $cmanager = $_SESSION['manager_username'];
            $pUsername = $_POST["username"];
            $pPassword = $_POST["password"];
            $pSurname = $_POST["surname"];
            $pFullnames = $_POST["fullname"];
            $pGender = $_POST["gender"];
            $pIDNo = $_POST["idNo"];
            $pEmail = $_POST["email"];
            $pCell = $_POST["cell"];
            $pTell = $_POST["tell"];
            $pRole = "Admin";
            
                Admin::addAdmin($pUsername,$pPassword,$pSurname,$pFullnames,$pGender,$pIDNo,$pEmail,$pCell,$pTell,$pRole,$cmanager);
                Render::render('Home');
        }
        else
        if(isset($_POST['btnHome']))
         {
              Render::render('Home');
              
         }
                 else
           {
               Render::render('Register');
            }

    
}
}
?>