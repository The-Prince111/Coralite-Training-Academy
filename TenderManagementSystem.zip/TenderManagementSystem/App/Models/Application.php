<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
  class Application {
      
    	public $appNo;
	public $appDate;
        public $appStatus;
	public $appBid;
        public $appAmount;
	public $tenDesc;
        public $username;
   
    	public function __construct($appNo, $appDate,$appStatus,$appBid,$appAmount,$tenDesc,$username) 
        {
      		$this->appNo= $appNo;
      		$this->appDate= $appDate;
                $this->appStatus= $appStatus;
      		$this->appBid= $appBid;
                $this->appAmount= $appAmount;
      		$this->tenDesc  = $tenDesc;
      		$this->username  = $username;
    	}

	public static function all()
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT *  FROM tbltenderapplication a  INNER JOIN tbluser u  ON a.user_no = u.user_no  INNER JOIN tbltender t  ON t.tender_no = a.tender_no WHERE application_status NOT LIKE 'Issued' ORDER BY t.tender_no DESC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $apps) 
                {
        		$list[] = new Application($apps['application_no'], $apps['application_date'], $apps['application_status'], $apps['application_dibDoc'], $apps['application_amount'], $apps['tender_description'], $apps['user_name']);
      		}

      	return $list;
    	}
        
    public function applytender($appBid,$appAmount,$userNo,$tenNo)
    {
        $sql = "INSERT INTO tbltenderapplication(application_date, application_status,application_bidDoc,application_amount,user_no, tender_no ) "
        ." VALUES (CURDATE(),'Not Issued','$appBid','$appAmount','$userNo','$tenNo' )" ;
        
        $db = DBConn::getInstance();
        $db->query($sql);
    }
     public function cancelapplication($userNo,$appNo)
    {
                $db = DBConn::getInstance();
                $sql = "UPDATE tbltenderapplication "
                            ."SET application_status = 'Cancelled' "
                                    ." WHERE application_no = '$appNo' " 
                                          ." AND user_no = '$userNo' ";
                $db->prepare($sql);
	      	$db->query($sql);
    }
    public function viewapplication($uname)
    {
      
              	$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT *  FROM tbltenderapplication a  INNER JOIN tbluser u  ON a.user_no = u.user_no  INNER JOIN tbltender t  ON t.tender_no = a.tender_no WHERE application_status = 'Not Issued' AND a.user_no = (SELECT user_no FROM tbluser WHERE user_username = '".$uname."' LIMIT 1) ORDER BY a.application_date ASC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $apps) 
                {
        		$list[] = new Application($apps['application_no'], $apps['application_date'], $apps['application_status'], $apps['application_dibDoc'], $apps['application_amount'], $apps['tender_description'], $apps['user_name']);
      		}

      	return $list;
    }
    
        public function viewapplications($uname,$comp)
    {
                 $list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT *  FROM tbltenderapplication a  INNER JOIN tbluser u  ON a.user_no = u.user_no  INNER JOIN tbltender t  ON t.tender_no = a.tender_no WHERE application_status NOT LIKE 'Issued' AND a.user_no = (SELECT user_no FROM tbluser WHERE user_username = '".$uname."' LIMIT 1) AND u.company_no = '$comp' ORDER BY a.application_date DESC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $apps) 
                {
        		$list[] = new Application($apps['application_no'], $apps['application_date'], $apps['application_status'], $apps['application_dibDoc'], $apps['application_amount'], $apps['tender_description'], $apps['user_name']);
      		}

      	return $list;
    }

            public function viewapps($comp)
    {
                 $list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT *  FROM tbltenderapplication a  INNER JOIN tbluser u  ON a.user_no = u.user_no  INNER JOIN tbltender t  ON t.tender_no = a.tender_no WHERE application_status NOT LIKE 'Issued'  AND u.company_no = '$comp' ORDER BY a.application_date DESC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $apps) 
                {
        		$list[] = new Application($apps['application_no'], $apps['application_date'], $apps['application_status'], $apps['application_dibDoc'], $apps['application_amount'], $apps['tender_description'], $apps['user_name']);
      		}

      	return $list;
    }
    
}
?>
