<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class appSummary
{

     public function appSumDate($midate,$madate,$uname)
     {
         
      	$db = DBConn::getInstance();   
        $sql = "SELECT COUNT(application_no) appTotal FROM tbltenderapplication a LEFT JOIN tbltender t ON a.tender_no = t.tender_no WHERE application_date BETWEEN '$midate' AND '$madate' AND t.user_no = (SELECT user_no FROM tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') LIMIT 1)";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $appsummaryDate) 
        {         
        $totApps = $appsummaryDate['appTotal'];
        }  
        return $totApps;
     }
}
?>
