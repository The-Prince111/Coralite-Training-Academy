<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class tenSummary
{
    public $totOpen;
    public $totClosed;
    public function __construct($totopen,$totclosed)
    {
        $this->totOpen = $totopen;
        $this->totClosed = $totclosed;
    }
    public function tenSum()
    {
                $list = array();
      	$db = DBConn::getInstance();   
        $sql = "SELECT COUNT(o.tenders) open_tenders,COUNT(c.tenders) closed_tenders 
                FROM (SELECT tender_no tenders FROM tbltender WHERE tender_closingDate > CURRENT_DATE) o,
                (SELECT tender_no tenders FROM tbltender WHERE tender_closingDate < CURRENT_DATE) c
                ";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $tensummary) 
        {         
        $list[] = new tenSummary($tensummary['open_tenders'], $tensummary['closed_tenders']);
        $i++;
        }         
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                } 
    }
    public function tenSumComp()
    {
    }
     public function tenSumDate($mid,$mad,$uname)
    {
      	$db = DBConn::getInstance();   
        $sql = "SELECT COUNT(tender_no) dateTotal FROM tbltender WHERE tender_datePosted BETWEEN '$mid' AND '$mad' AND user_no = (SELECT user_no FROM tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') LIMIT 1)
                ";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $tensummaryDate) 
        {         
        $totDate = $tensummaryDate['dateTotal'];
        }  
        return $totDate;
    }
    
         public function totPayDate($mid,$mad,$uname)
    {
      	$db = DBConn::getInstance();   
        $sql = "SELECT COUNT(payment_no) payTotal FROM tblpayment WHERE payment_date BETWEEN '$mid' AND '$mad' AND user_no = (SELECT user_no FROM tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') LIMIT 1)
                ";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $tenPayDate) 
        {         
        $totPayDate = $tenPayDate['payTotal'];
        }  
        return $totPayDate;
    }
    
         public function totSumDate($mid,$mad,$uname)
    {
      	$db = DBConn::getInstance();   
        $sql = "SELECT SUM(payment_amount) sumTotal FROM tblpayment WHERE payment_date BETWEEN '$mid' AND '$mad' AND user_no = (SELECT user_no FROM tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') LIMIT 1)";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $totSumDate) 
        {         
        $totSumDate = $totSumDate['sumTotal'];
        }  
        return $totSumDate;
    }
}
?>
