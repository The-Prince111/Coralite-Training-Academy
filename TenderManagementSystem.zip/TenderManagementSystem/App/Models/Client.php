<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Client
{
    public $username;
    public $password;
    public $surname;
    public $name;
    public $gender;
    public $idNo;
    public $email;
    public $cell;
    public $tell;
    public $role;
    public $company;
    
    public function __construct($username,$password,$surname,$name,$gender,$idNo,$email,$cell,$tell,$role,$company)
     {
        $this->username =$username;
        $this->password = $password;
        $this->surname = $surname;
        $this->name = $name;
        $this->gender = $gender;
        $this->idNo = $idNo;
        $this->email = $email;
        $this->cell = $cell;
        $this->tell = $tell;
        $this->role = $role;
        $this->company = $company;
        
     }
    public function viewprofile($username,$password)
    {
                $db = DBConn::getInstance();
		$sql = "SELECT * FROM tbluser WHERE user_username = '$username' AND user_password = '$password' LIMIT 1";
      		$db->prepare($sql);
		$req = $db->query($sql);
                  
      		$profile = $req->fetch(); 

      		return new Client($profile['user_username'], $profile['user_password'], $profile['user_surname'], $profile['user_name'], $profile['user_gender'], $profile['user_idNr'], $profile['user_email'], $profile['user_cellNr'], $profile['user_tellNr'], $profile['user_role'], $profile['company_no']);   
    }
    public  function updateprofile($username,$password,$surname,$name,$gender,$idNo,$email,$cell,$tell,$role,$uname)
    {
              	$db = DBConn::getInstance();
	  	$sql = "UPDATE tbluser SET user_username = '".$username."',user_password = '".$password."',user_surname = '".$surname."',user_name = '".$name."',user_gender = '".$gender."',user_idNr = '".$idNo."',user_email = '".$email."',user_cellNr = '".$cell."',user_tellNr = '".$tell."',user_role = '".$role."' WHERE user_username = '".$uname."' ";
	  	$db->prepare($sql);
	      	$db->query($sql);
        
    }

     
}
