<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class manSummary
{
public function totPostedTenders($uname)
{
        $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(tender_no) totTen 
FROM tbltender t
INNER JOIN tbluser u ON t.user_no = u.user_no
WHERE u.user_no = (SELECT user_no from tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') ORDER BY user_no ASC LIMIT 1)";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $totTens) 
        {         
        $totTenders = $totTens['totTen'];
        }  
        return $totTenders;
}
public function totOpenTenders($uname)
{
          	$db = DBConn::getInstance();   
                $sql = "SELECT COUNT(tender_no) totOpenTen FROM tbltender t INNER JOIN tbluser u ON t.user_no = u.user_no WHERE tender_closingDate > CURDATE()
                AND u.user_no = (SELECT user_no from tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') ORDER BY user_no ASC LIMIT 1)";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $Otenders) {
                    
                   $totOpenTenders =  $Otenders['totOpenTen'];
                }   
                return $totOpenTenders;
}
public function totClosedTenders($uname)
{
          	$db = DBConn::getInstance();   
                $sql = "SELECT COUNT(tender_no) totClosedTen FROM tbltender t INNER JOIN tbluser u ON t.user_no = u.user_no WHERE tender_closingDate < CURDATE()
                AND u.user_no = (SELECT user_no from tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') ORDER BY user_no ASC LIMIT 1)";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $Ctenders) {
                    
                   $totClosedTenders =  $Ctenders['totClosedTen'];
                }   
                return $totClosedTenders;

}
public function totApplications($uname)
{
        $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(application_no) appTotal FROM tbltenderapplication a LEFT JOIN tbltender t ON a.tender_no = t.tender_no WHERE t.user_no = (SELECT user_no from tbluser WHERE company_no = (SELECT company_no FROM tbluser WHERE user_username = '$uname') ORDER BY user_no ASC LIMIT 1)";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $appsummaryDate) 
        {         
        $totApps = $appsummaryDate['appTotal'];
        }  
        return $totApps;
}
public function totPayments($uname)
{
         $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(payment_no) payTotal FROM tblpayment WHERE user_no = (SELECT user_no FROM tbluser WHERE user_username = '$uname' LIMIT 1)
                ";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $tenPayDate) 
        {         
        $totPayDate = $tenPayDate['payTotal'];
        }  
        return $totPayDate;
}
}
?>