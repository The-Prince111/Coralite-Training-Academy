<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Category
{
    public $cat_id;
    public $cat_desc;
    
    
    public function __construct($cat_id,$cat_desc)
    {
        $this->cat_id = $cat_id;
        $this->cat_desc = $cat_desc;
    }
    public function getCategories()
    {
         $list = array();
         $db = DBConn::getInstance();
         $sql = "SELECT * FROM tblcategory";
         
         $sqlExec = $db->query($sql);
       
           $i = 0;
         foreach ($sqlExec->fetchAll() as $cat)
         {
             $list[] = new Category($cat['category_id'],$cat['category_desc']);
             $i++;
         }
         return $list;
    }
        public function getCategory($tenNo)
    {
                 $list = array();
         $db = DBConn::getInstance();
         $sql = "SELECT * FROM tblcategory c INNER JOIN tbltender t ON c.category_id = t.category_id WHERE tender_no = '$tenNo' LIMIT 1";
         
         $sqlExec = $db->query($sql);
       
           $i = 0;
         foreach ($sqlExec->fetchAll() as $cat)
         {
             $list[] = new Category($cat['category_id'],$cat['category_desc']);
             $i++;
         }
         return $list[0];
    }
}
