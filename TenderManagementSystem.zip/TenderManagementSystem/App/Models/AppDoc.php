<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class AppDoc
{
    public $appDoc_no;
    public $appDoc_document;
   
    public function __construct($appDocNo,$appDocDocument)
     {
        $this->appDoc_no = $appDocNo;
        $this->appDoc_document = $appDocDocument;
     }
     public function getAppDoc($appNo)
     {
     }
}
