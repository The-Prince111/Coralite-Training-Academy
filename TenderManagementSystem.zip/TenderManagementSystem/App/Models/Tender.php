<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
  class Tender {
      
    	public $ten_no;
	public $ten_region;
        public $ten_desc;
        public $ten_postDate;
        public $ten_closigDate;
        public $ten_status;
        public $ten_doc;
        public $ten_view;
        public $ten_cat;

        
        public function __construct($ten_no, $ten_region,$ten_desc,$ten_postDate,$ten_closigDate,$ten_status,$ten_doc,$ten_view,$ten_cat) 
        {
      		$this->ten_no  = $ten_no;
      		$this->ten_region  = $ten_region;
                $this->ten_desc  = $ten_desc;
      		$this->ten_postDate  = $ten_postDate;
                $this->ten_closigDate  = $ten_closigDate;
      		$this->ten_status  = $ten_status;
                $this->ten_doc  = $ten_doc;
      		$this->ten_view  = $ten_view;
                $this->ten_cat  = $ten_cat;
                
    	}

	public static function all()
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() ORDER BY tender_no DESC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
    public function advertisetender($ten_region,$ten_desc,$ten_closigDate,$ten_doc,$uno,$ten_cat)
    {
         $sql = "INSERT INTO tbltender(tender_region, tender_description,tender_datePosted,tender_closingDate,tender_status, tender_amount, tender_detailsDoc,tender_view,user_no,category_id ) "
        ." VALUES ('$ten_region','$ten_desc',CURDATE(),'$ten_closigDate','Not Approved',00.00,'$ten_doc',0,'$uno','$ten_cat' )" ;

        $db = DBConn::getInstance();
        $db->query($sql);
    }
    public function updatetender($ten_region,$ten_desc,$ten_closigDate,$ten_cat,$ten_no)
    {
        $db = DBConn::getInstance();
	  	$sql = "UPDATE tbltender SET tender_region = '".$ten_region."',tender_description = '".$ten_desc."',tender_closingDate = '".$ten_closigDate."',category_id = '".$ten_cat."' WHERE tender_no = '".$ten_no."' ";
	  	$db->prepare($sql);
	      	$db->query($sql);
        
    }
    //Gon' Use bellow for search criterion
    	public static function tenderDPC($date,$prov,$cat)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate BETWEEN CURDATE() AND '$date' AND t.tender_region = '$prov' AND t.category_id = '$cat' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
       public static function tenderDP($date,$prov)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate BETWEEN CURDATE() AND '$date' AND t.tender_region = '$prov' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
	public static function tenderDC($date,$cat)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate BETWEEN CURDATE() AND '$date' AND t.category_id = '$cat' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
         public static function tenderPC($prov,$cat)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() AND t.tender_region = '$prov' AND t.category_id = '$cat' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
        	public static function tenderP($prov)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() AND t.tender_region = '$prov' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
        	public static function tenderC($cat)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE()AND t.category_id = '$cat' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}
        	public static function tenderD($date)
        {
      		$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate BETWEEN CURDATE() AND '$date' ORDER BY tender_no DESC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $tenders)
                {
        		$list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
      		}

      	return $list;
    	}

        public function assignTender()
        {
        }
        public function approveTender()
        {
        }
            public function viewtenders()
    {
              	$list = array();
      		$db = DBConn::getInstance();   
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() ORDER BY tender_no ASC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $tenders) {
                    
                    $list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
                }

      	return $list;
    }
   public function gettendert($ten)
    {
                $list = array();
      		$db = DBConn::getInstance();   
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() AND t.tender_no = '$ten' ORDER BY tender_no DESC";
      		$req = $db->query($sql);
                $i = 0;
      		foreach($req->fetchAll() as $tenders) {
                    
                    $list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
                    $i++;
                }         
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                } 
    }
    
           public function gettender($comp,$ten)
    {
                $list = array();
      		$db = DBConn::getInstance();   
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() AND u.company_no = '$comp' AND t.tender_no = '$ten' ORDER BY tender_no DESC";
      		$req = $db->query($sql);
                $i = 0;
      		foreach($req->fetchAll() as $tenders) {
                    
                    $list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
                    $i++;
                }         
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                } 
    }
        public function viewtender($comp)
    {
                $list = array();
      		$db = DBConn::getInstance();   
                $sql = "SELECT * FROM tbltender t LEFT JOIN tbluser u ON t.user_no = u.user_no LEFT JOIN tblcategory c ON c.category_id = t.category_id WHERE tender_closingDate > CURDATE() AND u.company_no = '$comp' ORDER BY tender_no ASC";
      		$req = $db->query($sql);
      		foreach($req->fetchAll() as $tenders) {
                    
                    $list[] = new Tender($tenders['tender_no'], $tenders['tender_region'], $tenders['tender_description'], $tenders['tender_datePosted'], $tenders['tender_closingDate'], $tenders['tender_status'], $tenders['tender_detailsDoc'], $tenders['tender_view'], $tenders['category_desc']);
                }

      	return $list;
    }
    
    public function tenSummary($company)
    {
    }
}
?>
