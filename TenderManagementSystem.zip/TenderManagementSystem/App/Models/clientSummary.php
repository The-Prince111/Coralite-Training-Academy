<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class clientSummary
{
 
    public function clientSum($username)
    {
        $list = array();
      	$db = DBConn::getInstance();   
        $sql = "SELECT CONCAT(u.user_surname,' ',u.user_name) client_name,COUNT(a.application_no) client_apps
        FROM tbluser u 
        INNER JOIN tbltenderapplication a 
        ON u.user_no = a.user_no
        WHERE u.user_username = '$username'
        GROUP BY client_name";
      	$req = $db->query($sql);
        $i = 0;
      	foreach($req->fetchAll() as $csummary) 
        {         
        $list[] = new clientSummary($csummary['client_name'], $csummary['client_apps']);
        $i++;
        }         
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                } 
    }
    
    public function totUserApps($uname)
    {
        $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(application_no) userTotApps FROM tbltenderapplication WHERE  user_no = (SELECT user_no FROM tbluser WHERE user_username = '$uname') LIMIT 1";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $totUserApps) 
        {         
        $totUserApps = $totUserApps['userTotApps'];
        }  
        return $totUserApps;
    }
        public function clientApprovedApps($uname)
    {
        $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(application_no) userTotApprovedApps FROM tbltenderapplication WHERE application_status = 'Issued' AND user_no = (SELECT user_no FROM tbluser WHERE user_username = '$uname') LIMIT 1";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $totAppApps) 
        {         
        $usertotAppApps = $totAppApps['userTotApprovedApps'];
        }  
        return $usertotAppApps;
    }
    public function clientPendingApps($uname)
    {
        $db = DBConn::getInstance();   
        $sql = "SELECT COUNT(application_no) userTotPendingApps FROM tbltenderapplication WHERE application_status NOT LIKE 'Issued' AND user_no = (SELECT user_no FROM tbluser WHERE user_username = '$uname') LIMIT 1";
      	$req = $db->query($sql);
        
      	foreach($req->fetchAll() as $totPendingApps) 
        {         
        $usertotPendApps = $totPendingApps['userTotPendingApps'];
        }  
        return $usertotPendApps;
    }
    
    public function totOpenTenders()
    {
      		$db = DBConn::getInstance();   
                $sql = "SELECT COUNT(*) totOpenTen FROM tbltender  WHERE tender_closingDate > CURDATE() ";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $Otenders) {
                    
                   $totOpenTenders =  $Otenders['totOpenTen'];
                }   
                return $totOpenTenders;
    }
    public function totClosedTenders()
    {
                $db = DBConn::getInstance();   
                $sql = "SELECT COUNT(*) totClosedTen FROM tbltender  WHERE tender_closingDate < CURDATE() ";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $Ctenders) {
                    
                   $totClosedTenders =  $Ctenders['totClosedTen'];
                }   
                return $totClosedTenders;
    }
         public function getUserFullnames($uname,$pword)
     {
         $db = DBConn::getInstance();
         $sql = "SELECT CONCAT(user_surname,' ',user_name) fullnames FROM tbluser WHERE user_username = '$uname' AND user_password = '$pword' LIMIT 1";
         
         $sqlExec = $db->query($sql);
         
         foreach ($sqlExec->fetchAll() as $userNames)
         {
            $UserFullnames = $userNames['fullnames'];
         }
         return $UserFullnames;
     }
}
?>

