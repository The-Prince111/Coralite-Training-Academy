<?php

class Render
{
    public function __construct() 
    {
        //require_once 'Application/Views/Public/Home.php';
    }
   
    public static function  render($viewScript)
    {
        if($viewScript == 'Error')
        {
            require_once 'Public/Error.php';
        }
        if($viewScript == 'Home')
        {
            require_once 'Public/Home.php';
        }
        else if($viewScript == 'Contact')
        {
             require_once 'Public/Contact.php';
        }
        else if($viewScript == 'About')
        {
             require_once 'Public/About.php';
        }
        else if ($viewScript == 'Login')
        {
            require_once 'Public/Login.php';
        }
        else if ($viewScript == 'LoggedIn')
        {
            require_once 'Public/LoggedIn.php';
        }
        else if ($viewScript == 'Register')
        {
            require_once 'Public/Register.php';
        }
        else if ($viewScript == 'AHome')
        {
            require_once 'App/Views/Admin/AdminMenu.php';
        }
        else if ($viewScript == 'CHome')
        {
            require_once 'App/Views/Client/ClientMenu.php';
        }
        else if ($viewScript == 'MHome')
        {
            require_once 'App/Views/Manager/ManagerMenu.php';
        }
        
    }
}


