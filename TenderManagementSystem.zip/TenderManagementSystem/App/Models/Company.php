<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Company
{
    public $comp_no;
    public $comp_name;
    public $comp_type;
    public $comp_street;
    public $comp_town;
    public $comp_code;
    public $comp_province;
    
     public function __construct($compNo,$compName,$compType,$compStreet,$compTown,$compCode,$compProvince)
     {
        $this->comp_no = $compNo;
        $this->comp_name = $compName;
        $this->comp_type= $compType;
        $this->comp_street = $compStreet;
        $this->comp_town = $compTown;
        $this->comp_code= $compCode;
        $this->comp_province = $compProvince;
        
     }
     public function addCompany($cname,$ctype,$cprov,$ctown,$cstreet,$ccode,$cman)
     {
         $sql = "CALL addCompany('$cname','$ctype','$cprov','$ctown','$cstreet',$ccode,'$cman')";
        $db = DBConn::getInstance();
        $db->query($sql);
     }
     public function getCompany($userNo)
     {
               	$list = array();
      		$db = DBConn::getInstance();
                $sql = "SELECT * FROM tblcompany c INNER JOIN tbluser u ON c.company_no = u.company_no WHERE u.username = '$userNo' LIMIT 1 ORDER BY company_no ASC";
      		$req = $db->query($sql);
                
      		foreach($req->fetchAll() as $company)
                {
        		$list[] = new Company($company['company_name'], $company['company_type'], $company['company_addressStreet'], $company['company_addressTown'], $company['company_province'],$company['company_addressCode']);
      		}

      	return $list;
     }
}