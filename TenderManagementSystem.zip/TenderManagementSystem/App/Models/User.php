<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class User
{
    
    public $rUserNo;
    public $rUsername;
    public $rPassword;
    public $rSurname;
    public $rFullnames;
    public $rGender;
    public $rIDNo;
    public $rEmail;
    public $rCell;
    public $rTell;
    public $rRole;
    public $rCompany;
    

    public function __construct($uUserNo,$uUsername,$uPassword,$uSurname,$uFullnames,$uGender,$uIDNo,$uEmail,$uCell,$uTell,$uRole,$ruComp)
     {
        $this->rUserNo = $uUserNo;
        $this->rUsername =$uUsername;
        $this->rPassword = $uPassword;
        $this->rSurname = $uSurname;
        $this->rFullnames = $uFullnames;
        $this->rGender = $uGender;
        $this->rIDNo = $uIDNo;
        $this->rEmail = $uEmail;
        $this->rCell = $uCell;
        $this->rTell = $uTell;
        $this->rRole = $uRole;
        $this->rCompany = $ruComp;
        
     }
     
     public static function addUser($rUsername,$rPassword,$rSurname,$rFullnames,$rGender,$rIDNo,$rEmail,$rCell,$rTell,$rRole)
    {
        
        $sql = "INSERT INTO tbluser(user_username, user_password,user_surname,user_name,user_gender, user_idNr, user_email, user_cellNr, user_tellNr, user_role ) "
        ." VALUES ('$rUsername','$rPassword','$rSurname','$rFullnames','$rGender','$rIDNo','$rEmail','$rCell','$rTell','$rRole' )" ;

        $db = DBConn::getInstance();
        $db->query($sql);
    }
    
     
     public static function getUser($rUsername, $rPassword)
     {
         $list = array();
         $db = DBConn::getInstance();
         $sql = "SELECT * FROM tbluser WHERE user_username = '$rUsername' AND user_password = '$rPassword' LIMIT 1";
         
         $sqlExec = $db->query($sql);
       
           $i = 0;
         foreach ($sqlExec->fetchAll() as $user)
         {
             $list[] = new User($user['user_no'],$user['user_username'],$user['user_password'],$user['user_surname'],$user['user_name'],$user['user_gender'],$user['user_idNr'],$user['user_email'],$user['user_cellNr'],$user['user_tellNr'],$user['user_role'],$user['company_no']);  // wrong
             $i++;
         }
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                }   
     }
          public static function getUserNo($rUsername, $rPassword)
     {
         $list = array();
         $db = DBConn::getInstance();
         $sql = "SELECT user_no FROM tbluser WHERE user_username = '$rUsername' AND user_password = '$rPassword' LIMIT 1";
         
         $sqlExec = $db->query($sql);
       
           $i = 0;
         foreach ($sqlExec->fetchAll() as $user)
         {
             $list[] = new User($user['user_no'],$user['user_username'],$user['user_password'],$user['user_surname'],$user['user_name'],$user['user_gender'],$user['user_idNr'],$user['user_email'],$user['user_cellNr'],$user['user_tellNr'],$user['user_role'],$user['company_no']);
             $i++;
         }
         if($i>0)
         {
             return $list[0];
         }
            else 
                {    
                return false;
                }   
     }
     

}



?>
