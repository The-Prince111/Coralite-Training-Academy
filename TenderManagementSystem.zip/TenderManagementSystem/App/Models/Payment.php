<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Payment
{
    public $payment_no;
    public  $payment_date;
    public $payment_amount;
    public $payment_reciept;
    
    public function __construct($payNo,$payDate,$payAmount,$payReciept)
     {
        $this->payment_no = $payNo;
        $this->payment_date = $payDate;
        $this->payment_amount= $payAmount;
        $this->payment_reciept = $payReciept;
        
     }
     public function makePayment()
     {
         
     }
     public function viewPayment()
     {
     }
}

