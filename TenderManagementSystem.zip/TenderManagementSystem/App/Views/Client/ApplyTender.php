<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Apply Tender</title>
    </head>
    <body>
        <div class="content">
            <br><br><br><br><br><br>
                                  <div class="apptender">
  <?php
        echo"  <form action='' method='post'>
        <div class='pagehead'>APPLY TENDER HERE</div>
        <br> ";
        if(isset($_POST['tenderNo']))
        {
            $tenNo = $_POST['tenderNo'];
   echo" Tender No. <br> <input type='text' name='tenderNo' class='textbox' disabled value='$tenNo'><br><br>
    <input type='hidden' name='tenderNumber' value='$tenNo'>";
        }
        else
        {
        echo"        Tender No. <br> <input type='text' name='tenderNo' class='textbox' disabled value=".$tenderNo->ten_no."><br><br>
    <input type='hidden' name='tenderNumber' value=".$tenderNo->ten_no."> ";
        }
        
        if(isset($_POST['tenderDesc']))
        {
            $tenDesc = $_POST['tenderDesc'];
    echo "Description<br>  <input type='text' name='tenderDesc' class='textbox' disabled value='$tenDesc'><br><br> ";
        }
        else
        {
           echo" Description<br>  <input type='text' name='tenderDesc' class='textbox' disabled value=".$tenderNo->ten_desc."><br><br> ";
        }

        if(isset($_POST['amount']))
        {
            $amt = $_POST['amount'];
         echo "Amount<br>  <input type='text' name='amount' class='textbox' value = '$amt'><br><br> ";
        }
        else 
        {
            echo "Amount<br>  <input type='text' name='amount' class='textbox'><br><br> ";
        }
        echo"
    Application Document <br> <input type='file' name='bid' class='textbox'><br><br>
    <br>
     <input type='submit' name='btnApplyTender' value='Apply Tender' class='buttonLogin'>
    <input type='submit' name='btnHome' value='Home' class='buttonCancel'><br><br>
</form> ";
 ?>
        </div>
        </div>
    </body>
</html>
</div>