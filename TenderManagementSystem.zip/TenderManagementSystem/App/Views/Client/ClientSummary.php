<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Client Summary</title>
    </head>
    <body>
<?php
 include 'CHeader.php';
?>
        <div class="mcontent">
       <div class="sum">         

           <form name='clientSum' method = POST onchange='clientSum.submit()' onsubmit="window.location.reload()"> 
<div class='pagehead'>CLIENT SUMMARY</div><br>
</br></br>

  <table class="custom-table">
    <tr>
          <th>       </th>
      <th>       </th>
      <th>Headers</th>
      <th>       </th>
      <th>       </th>
      <th>       Values</th>
    </tr>
            <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
            <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
        <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
            <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Full Names</td>
      <td></td>
      <td>:</td>
      <td><?php echo $userNames; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Total Applications</td>
      <td></td>
      <td>:</td>
      <td><?php echo $clientApps; ?></td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Approved Apps</td>
      <td></td>
      <td>:</td>
      <td><?php echo $clientApprovedApps; ?></td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Pending Apps</td>
      <td></td>
      <td>:</td>
      <td><?php echo $clientPendingApps; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Current Open Tenders</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totOpenTenders; ?></td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Total Missed/Expired Tenders</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totExpTenders; ?></td>
    </tr>
    </tr>
        <tr>
      <th>       </th>
      <th>       </th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </table>

</table>
</br></br></br>

</form>
        </div>
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>