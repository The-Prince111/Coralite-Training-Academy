<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>View Profile</title>
    </head>
    <body>
        
        <div class="content">
            <br/>
                      <div class="reg">
<form action='' method=POST>
    <div class="pagehead">UPDATE PROFILE</div>
<table>
<?php
	echo "
<tr><td>Username</td><tr/><tr><td><input type=text class=textbox name=username value =".$userprofile->username."></td></tr>
 <tr><td>Password</td><tr/><tr><td><input type=text class=textbox name=password value =".$userprofile->password."></td></tr>
 <tr><td>Surname</td><tr/><tr><td><input type=text class=textbox name=surname value =".$userprofile->surname."></td></tr>
<tr><td>Full names</td><tr/><tr><td><input type=text class=textbox name=name value =".$userprofile->name."></td></tr>
<tr><td>Gender</td><tr/><tr><td><input type=text class=textbox name=gender value =".$userprofile->gender."></td></tr>
<tr><td>Id No.</td><tr/><tr><td><input type=text class=textbox name=idNo value =".$userprofile->idNo."></td></tr>
<tr><td>Email</td><tr/><tr><td><input type=text class=textbox name=email value =".$userprofile->email."></td></tr>
<tr><td>Cell No.</td><tr/><tr><td><input type=text class=textbox name=cell value =".$userprofile->cell."></td></tr>
<tr><td>Tell No.</td><tr/><tr><td><input class=textbox type=text name=tell value =".$userprofile->tell."></td></tr>
<tr><td>Role</td><tr/><tr><td><input class=textbox type=text name=role disabled value =".$userprofile->role."><input hidden class=textbox type=text name=role value =".$userprofile->role."></td></tr>
<tr><td span=2><input type=hidden name=controller value=Client>
<input type=hidden name=action value=viewprofile>
</td></tr></table>
<br/>
<input type=submit name=btnSaveChanges class=buttonLogin value='Save Changes'>
<input type=submit name=btnHome class=buttonCancel value='Home'>
</form>
";

?>
        </div>
        </div>
    </body>
</html>
</div>