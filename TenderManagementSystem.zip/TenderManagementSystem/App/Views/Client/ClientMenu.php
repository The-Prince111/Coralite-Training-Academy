<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Client Portal</title>
    </head>
    <body>
<?php
 include 'CHeader.php';
?>
        <div class="mcontent">
Client Home
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>