<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Client Menu</title>
    </head>
    <body>
        <div class="header">
         <div class="inheaderleft"></div>   
         <div class="inheaderright">
             <div class="menu">
    <ul>
      <li><a href="?controller=Client&action=home">Home</a></li>
      <li><a href="?controller=Client&action=viewprofile">View Profile</a></li>
      <li><a href="?controller=Client&action=viewtender">View Available Tenders</a></li>
      <li><a href="?controller=Client&action=viewapplication">View Application</a></li>
      <li><a href="?controller=Index&action=logout">Logout</a></li>
    </ul> 
                 
             </div>
         </div>  
        </div>
        <div class="clear"></div>
</body>
</html>
