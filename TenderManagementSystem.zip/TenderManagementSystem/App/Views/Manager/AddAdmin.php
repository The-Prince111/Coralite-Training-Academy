<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Add Admin</title>
    </head>
    <body>
        <div class="content">
           <br/>
          <div class="reg">
<form action="" method="post">
    <div class="otherhead">ADD ADMIN HERE</div>
    <br>
  Username<br>
  <input type="text" name="username" required class="textbox"><br>
  Password<br>
  <input type="password" name="password" required class="textbox"><br>
  Surname<br>
  <input type="text" name="surname" required class="textbox"><br>
  Full names<br>
  <input type="text" name="fullname" required class="textbox"><br>
  Gender<br>
  <input type="radio" name="gender" value="male" > Male
  <input type="radio" name="gender" value="female"> Female<br>
  ID No.<br>
  <input type="text" name="idNo"  max='13' required class="textbox"><br>
  Email<br>
  <input type="email" name="email" required  class="textbox"><br>
  Cell No.<br>
  <input type="number" name="cell" required pattern="[0-9]" class="textbox"><br>
  Tell No.<br>
  <input type="number" name="tell" pattern="[0-9]" class="textbox"><br>
  <br><br><br><br>
        <button type="submit" name="btnAddAdmin" class="buttonLogin" value="Continue">Continue</button><br>
</form>

            </div>
        </div>

    </body>
</html>
</div>