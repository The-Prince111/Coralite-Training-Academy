<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Approve Tender</title>
    </head>
    <body>
         <div class="content">
             <br>
                      <div class="ten">

<?php         

echo "<form method = POST>";
echo "<div class='pagehead'>ADVERTISED TENDERS</div><br>";
echo "<table><tr><th>Tender No.</th><th>Rigion</th><th>Description</th><th>Posted Date</th><th>Closing Date</th><th>Category</th><th>Advertised By</th><th>Action</tr>";
foreach ($mantenders as $ten) 
{
echo "<tr>
<td>$ten->ten_no</td>
<td>$ten->ten_region</td>
<td>$ten->ten_desc</td>
<td>$ten->ten_postDate</td>
<td>$ten->ten_closigDate</td>
<td>$ten->ten_cat</td>
<td>$ten->ten_status</td>
<td><input type=hidden name=tenNo value = ".$ten->ten_no.">
 <td><input type=hidden name=tenDesc value = ".$ten->ten_desc.">
 <input type=submit name=btnApprove value=Approve>
 </td>
</tr>";

}
?>
</table>
<br/>
    <?php
echo "<input type=hidden name=controller value = Manager>";
echo "<input type=hidden name=action value = approvetender>";
echo '<input type=submit name=btnHome class=buttonCancel value=Home>';

?>
</form>
        </div>
     </div>
    </body>
    </body>
</html>
</div>