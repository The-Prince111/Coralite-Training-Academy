<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Payments Summary</title>
    </head>
    <body>
<?php
 include 'MHeader.php';
?>
        <div class="mcontent">
                  <div class="sum">
 <form name='paySum' method = POST onchange='paySum.submit()'> 
<div class='pagehead'>PAYMENTS' SUMMARY</div><br>
Payments Made between
  <input type="date" name="mindate" value="<?php echo $min_date; ?>" />
  and
  <input type="date" name="maxdate" value="<?php echo $max_date; ?>" /><br>
</br></br>

  <table class="custom-table">
    <tr>
          <th>       </th>
      <th>       </th>
      <th>Headers</th>
      <th>       </th>
      <th>       </th>
      <th>       Values</th>
    </tr>
                <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
            <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
    
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Period</td>
      <td></td>
      <td>:</td>
      <td><?php echo $interval; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Total Payments Made</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totPayments; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Amount Paid</td>
      <td></td>
      <td>:</td>
      <td>R<?php echo $totAmount; ?></td>
    </tr>
  </table>

</table>
</br></br></br>
<input type=hidden name=controller value = Manager>
<input type=hidden name=action value = home>
<input type=submit name=btnHome class=buttonCancel value=Home>

</form>
        </div>
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>
