<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Manager Menu</title>
    </head>
    <body>
        <div class="header">
         <div class="inheaderleft"></div>   
         <div class="inheaderright">
             <div class="menu">
    <ul>
        <li><a href="?controller=Manager&action=home">Home</a></li>
      <li><a href="?controller=Manager&action=viewapplicationreport">Applications</a></li>
       <li><a href="?controller=Manager&action=viewpaymentreport">Payment</a></li>
      <li><a href="?controller=Manager&action=assigntender">Assign Tender</a></li>
      <li><a href="?controller=Manager&action=approvetender">Approve Tender</a></li>
      <li><a href="?controller=Index&action=logout">Logout</a></li>
    </ul> 
                 
             </div>
         </div>  
        </div>
        <div class="clear"></div>
</body>
</html>
