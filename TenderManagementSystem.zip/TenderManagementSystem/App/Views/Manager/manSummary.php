<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Manager Summary</title>
    </head>
    <body>
<?php
 include 'MHeader.php';
?>
        <div class="mcontent">
       <div class="sum">         

           <form name='manSum' method = POST onchange='manSum.submit()' onsubmit="window.location.reload()"> 
<div class='pagehead'>MANAGER SUMMARY</div><br>
</br></br>

  <table class="custom-table">
    <tr>
          <th>       </th>
      <th>       </th>
      <th>Headers</th>
      <th>       </th>
      <th>       </th>
      <th>       Values</th>
    </tr>
            <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
            <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
        <tr>
          <th>       </th>
      <th>       </th>
      <th></th>
      <th>       </th>
      <th>       </th>
      <th>      </th>
    </tr>
            <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Posted Tenders</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totPostedTenders; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Total Open Tenders</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totOpenTenders; ?></td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Current Closed Tenders</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totClosedTenders; ?></td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Applications Made</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totApplications; ?></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Payments Made</td>
      <td></td>
      <td>:</td>
      <td><?php echo $totPayments; ?></td>
    </tr>
    </tr>
        <tr>
      <th>       </th>
      <th>       </th>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </table>

</table>
</br></br></br>

</form>
        </div>
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>
