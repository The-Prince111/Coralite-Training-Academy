<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="../Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Manager Portal</title>
    </head>
    <body>
<?php
 include 'MHeader.php';
?>
        <div class="mcontent">
Manager Home
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>