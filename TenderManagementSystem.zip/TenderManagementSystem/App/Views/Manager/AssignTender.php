<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Assign Tender</title>
    </head>
    <body>
                 <div class="content">
             <br><br>
                      <div class="ten">
<?php
echo "<form method = POST>";
echo "<div class='pagehead'>ASSIGN TENDERS</div><br>";
 echo "<table><tr><th>Application No.</th><th>Date Applied</th><th>Status</th><th>Document</th><th>Amount</th><th>Tender</th><th>Posted By</th><th>Applied By</th><th>Action</tr>";
foreach ($manApplications as $apps) 
{
echo "<tr>
<td>$apps->appNo</td>
<td>$apps->appDate</td>
<td>$apps->appStatus</td>
<td>$apps->appBid</td>
<td>$apps->appAmount</td>
<td>$apps->tenDesc</td>
<td>$apps->username</td>
<td>$apps->username</td>
 <td><input type=hidden name=appNo value = ".$apps->appNo.">
 <td><input type=hidden name=appUser value = ".$apps->username.">
 <input type=submit name=btnAssign value=Assign>
 </td>
</tr>";

}
?>
</table>
<br/><br/><br/><br/>
 <?php
echo "<input type=hidden name=controller value = Manager>";
echo "<input type=hidden name=action value = assigntender>";
echo '<input type=submit name=btnHome class=buttonCancel value=Home>';

?>
  
</form>
        </div>
     </div>
    </body>
</html>
</div>
