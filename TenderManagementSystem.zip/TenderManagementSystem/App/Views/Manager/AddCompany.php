<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Add Company</title>
    </head>
    <body>
        <div class="content">
           <br/>
          <div class="reg">
<form action="" method="post">
    <div class="otherhead">ADD COMPANY HERE</div>
    <br>
  Company Name<br>
  <input type="text" name="copmname" required class="textbox"><br>
  Type<br>
  <input type="text" name="comptype" required class="textbox"><br>
  Province<br>
   <select name='compprovince'  class='shorttextbox'>
     <option selected >Province</option>
    <option>Mpumalanga</option>
    <option>Gauteng</option>
    <option>Limpopo</option>
    <option>North West</option>
    <option>Eastern Cape</option>
    <option>Western Cape</option>
    <option>Free State</option>
    <option>Northen Cape</option>
    <option>Kwazulu Natal</option>
 </select><br>
  Town<br>
  <input type="text" name="comptown" required class="textbox"><br>
  Street<br>
  <input type="text" name="compstreet" rerquired class="textbox"><br>
  Code<br>
  <input type="text" name="compcode" max='4' required  class="textbox"><br>
  <br><br><br><br><br><br><br><br><br><br>
        <button type="submit" name="btnAddCompany" class="buttonLogin" value="Continue">Continue</button><br>
</form>

            </div>
        </div>

    </body>
</html>
</div>

