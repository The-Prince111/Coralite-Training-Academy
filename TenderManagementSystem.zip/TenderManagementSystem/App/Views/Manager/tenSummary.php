<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Tender Summary</title>
    </head>
    <body>
<?php
 include 'MHeader.php';
?>
        <div class="mcontent">
                                        <div class="sum">
                          <form name='opentenders' action='' method=POST >

<?php         

echo "<form method = POST>";
echo "<div class='pagehead'>MANAGER SUMMARY</div><br>";
echo'</br></br>';
echo '
  <table class="custom-table">
    <tr>
          <th>       </th>
      <th>       </th>
      <th>Headers</th>
      <th>       </th>
      <th>       </th>
      <th>       Values</th>
    </tr>
    <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Total Posted Tenders</td>
      <td></td>
      <td>:</td>
      <td>50</td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Expired Tenders</td>
      <td></td>
      <td>:</td>
      <td></td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>   >    </th>
      <td>Current Open Tenders</td>
      <td></td>
      <td>:</td>
      <td>10</td>
    </tr>
    <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Applications Made</td>
      <td></td>
      <td>:</td>
      <td>30</td>
    </tr>
        <tr>
      <th>   <    </th>
      <th>    >   </th>
      <td>Total Payments Made</td>
      <td></td>
      <td>:</td>
      <td>30</td>
    </tr>
  </table>
';
echo "</table>";
echo'</br></br></br>';
echo "<input type=hidden name=controller value = Client>";
echo "<input type=hidden name=action value = home>";
echo '<input type=submit name=btnHome class=buttonCancel value=Home>';

?>
</form>
        </div>
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>
