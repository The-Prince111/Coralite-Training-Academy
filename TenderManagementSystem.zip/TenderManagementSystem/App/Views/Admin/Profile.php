<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>My Profile</title>
    </head>
    <body>  
        <div class="content">
             <br/>
                      <div class="profile">
                 
<form action='' method=POST>
        <div class="pagehead">PROFILE</div>
    <br>
<table>
<?php
	echo "
<tr><td>Username</td><tr/><tr><td><lable >$adminprofile->username</lable></td></tr>
 <tr><td>Password</td><tr/><tr><td><alble>$adminprofile->password</lable></td></tr>
 <tr><td>Surname</td><tr/><tr><td><lable>$adminprofile->surname</lable></td></tr>
<tr><td>Full names</td><tr/><tr><td><lable>$adminprofile->name</lable></td></tr>
<tr><td>Gender</td><tr/><tr><td><lable>$adminprofile->gender</lable></td></tr>
<tr><td>Id No.</td><tr/><tr><td><lable>$adminprofile->idNo</lable></td></tr>
<tr><td>Email</td><tr/><tr><td><lable>$adminprofile->email</lable></td></tr>
<tr><td>Cell No.</td><tr/><tr><td><lable>$adminprofile->cell</lable></td></tr>
<tr><td>Tell No.</td><tr/><tr><td><lable>$adminprofile->tell</lable></td></tr>
<tr><td>Role</td><tr/><tr><td><lable>$adminprofile->role</lable></td></tr>
<tr><td span=2>
</td></tr></table>
<br/><br/><br/><br/>
<input type=submit name=btnUpdate class=buttonLogin value='Update Profile'>
<input type=submit name=btnHome class=buttonCancel value='Home'>

</form>
";

?>
    </div>
        </div>
    </body>
</html>
</div>

