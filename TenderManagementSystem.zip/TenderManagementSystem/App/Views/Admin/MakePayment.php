<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="../Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Make Payment</title>
    </head>
    <body>
<?php
 include 'AHeader.php';
?>
        <div class="content">
           Make Payment Here
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>