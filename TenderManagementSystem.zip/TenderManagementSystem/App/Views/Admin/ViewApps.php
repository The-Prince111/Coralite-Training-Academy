<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Tender Applications</title>
    </head>
    <body>
         <div class="content">
             <br><br>
                      <div class="ten">
<form action='' method=POST>

<?php
echo "<form method = POST>";
echo "<div class='pagehead'>APPLICATIONS' MADE</div><br>";
 echo "<table><tr><th>Application No.</th><th>Date Applied</th><th>Status</th><th>Document</th><th>Amount</th><th>Tender</th><th>Posted By</tr>";
foreach ($adminApplications as $apps) 
{
echo "<tr>
<td>$apps->appNo</td>
<td>$apps->appDate</td>
<td>$apps->appStatus</td>
<td>$apps->appBid</td>
<td>$apps->appAmount</td>
<td>$apps->tenDesc</td>
<td>$apps->username</td>
</tr>";

}
?>
</table>
<br/><br/><br/><br/>
 <?php
echo "<input type=hidden name=controller value = Admin>";
echo "<input type=hidden name=action value = home>";
echo '<input type=submit name=btnHome class=buttonCancel value=Home>';

?>
  
</form>
        </div>
     </div>
    </body>
</html>
</div>