<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Admin Menu</title>
    </head>
    <body>
        <div class="header">
         <div class="inheaderleft"></div>   
         <div class="inheaderright">
             <div class="menu">
    <ul>
      <li><a href="?controller=Admin&action=viewprofile">View Profile</a></li>
      <li><a href="?controller=Admin&action=viewtender">Advertised Tenders</a></li>
      <li><a href="?controller=Admin&action=advertisetender">Advertise Tender</a></li> 
      <li><a href="?controller=Admin&action=viewapplication">View Applications</a></li>
      <li><a href="?controller=Index&action=logout">Logout</a></li>
    </ul> 
                 
             </div>
         </div>  
        </div>
        <div class="clear"></div>
</body>
</html>
