<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Footer</title>
    </head>
    <body>
        <div class="clear"></div>
        <div class="footer">
            <p style="height: 3px; text-align: left; margin-left: 80px"></p>
        <p style="height: 30px; text-align: left; float: left; margin-left: 80px">All rights reserved 2018,<br>Tenders Coporation<br><br>Branded Tenders <br>
        </p>
         <p style="height: 30px; text-align: left; float: right; margin-right: 80px">Private Bag x113<br>Witbank<br>Mandela Drive<br>1034 <br>
            
        </p>
        </div>
    </body>
</html>
