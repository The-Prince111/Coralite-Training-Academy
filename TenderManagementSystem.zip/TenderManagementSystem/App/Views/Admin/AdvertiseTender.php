<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Advertise Tender</title>
    </head>
    <body>
        <div class="content">
            <br>
            <div class="reg">
            <form action="" method="POST">
                <div class="pagehead">ADVERTISE TENDER HERE</div>
        <br>
    Tender Region <br>
    <select name="province" multiple="multiple" class="list">
    <option>Mpumalanga</option>
    <option>Gauteng</option>
    <option>Limpopo</option>
    <option>North West</option>
    <option>Eastern Cape</option>
    <option>Western Cape</option>
    <option>Free State</option>
    <option>Northen Cape</option>
    <option>Kwazulu Natal</option>
 </select><br> <br>
   Description<br>  <input type="text" name="description" class="textbox"><br><br> 
   Closing Date<br> <input type="date" name="closingDate" class="textbox"><br><br>
Category 
<br />

<?php
echo "<select name='category' class='textbox' >";

foreach ($categories as $category)
{
echo "<option value='" . $category->cat_id ."'>" . $category->cat_desc."</option>";
}
echo "</select>";
?>
<br/><br/>
    Detailed Document<br> <input type="file" name="bid" class="textbox"><br>
    <br><br><br>
    <input type="submit" name="btnAvertiseTender" value="Advertise Tender" class="buttonLogin"><br>
    <input type="submit" name="btnHome" value="Home" class="buttonCancel"><br>
  <br>
</form>
        </div>
            </div>
    </body>
</html>
</div>