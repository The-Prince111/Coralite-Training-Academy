<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>My Profile</title>
    </head>
    <body>
        
        <div class="content">
            <br>
                      <div class="reg">
<form action='' method=POST>
    <div class="pagehead">UPDATE PROFILE</div>
<table>
<?php
	echo "
<tr><td>Username</td><tr/><tr><td><input type=text class=textbox name=username value =".$adminprofile->username."></td></tr>
 <tr><td>Password</td><tr/><tr><td><input type=text class=textbox name=password value =".$adminprofile->password."></td></tr>
 <tr><td>Surname</td><tr/><tr><td><input type=text class=textbox name=surname value =".$adminprofile->surname."></td></tr>
<tr><td>Full names</td><tr/><tr><td><input type=text class=textbox name=name value =".$adminprofile->name."></td></tr>
<tr><td>Gender</td><tr/><tr><td><input type=text class=textbox name=gender value =".$adminprofile->gender."></td></tr>
<tr><td>Id No.</td><tr/><tr><td><input type=text class=textbox name=idNo value =".$adminprofile->idNo."></td></tr>
<tr><td>Email</td><tr/><tr><td><input type=text class=textbox name=email value =".$adminprofile->email."></td></tr>
<tr><td>Cell No.</td><tr/><tr><td><input type=text class=textbox name=cell value =".$adminprofile->cell."></td></tr>
<tr><td>Tell No.</td><tr/><tr><td><input class=textbox type=text name=tell value =".$adminprofile->tell."></td></tr>
<tr><td>Role</td><tr/><tr><td><input class=textbox disabled type=text name=role value =".$adminprofile->role."><input class=textbox type=text hidden name=role value =".$adminprofile->role."></td></tr>
<tr><td span=2><input type=hidden name=controller value=Admin>
<input type=hidden name=action value=viewprofile>
</td></tr></table>
<br/>
<input type=submit name=btnSaveCanges class=buttonLogin value='Save Changes'>
<input type=submit name=btnHome class=buttonCancel value='Home'>
</form>
";

?>
        </div>
        </div>
    </body>
</html>
</div>