<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Update Tenders</title>
    </head>
    <body>
        <div class="content">
                      <br>
                      <div class="reg">
<form action='' method=POST>
    <div class="pagehead">UPDATE TENDER</div>
<table>
<?php
	echo "       <br>
    Tender Number<br> <label for='Tender Number'>$admintender->ten_no</label>
    <input type='hidden' name='tenNo' value=".$admintender->ten_no."><br><br>
    Tender Region <br>
    <select name='province' multiple='multiple' class='list'>
    <option value=".$admintender->ten_region." selected='selected'>".$admintender->ten_region."</option>
    <option>Mpumalanga</option>
    <option>Gauteng</option>
    <option>Limpopo</option>
    <option>North West</option>
    <option>Eastern Cape</option>
    <option>Western Cape</option>
    <option>Free State</option>
    <option>Northen Cape</option>
    <option>Kwazulu Natal</option>
 </select><br> <br>
   Description<br>  <input type='text' name='description' class='textbox' value =".$admintender->ten_desc."><br><br> 
   Closing Date<br> <input type='date' name='closingDate' class='textbox' value =".$admintender->ten_closigDate."><br><br>
Category 
<br />";

echo "<select name='category' class='textbox' >";
echo "<option selected='selected' value='" . $tencat->cat_id ."' >".$tencat->cat_desc."</option>";
foreach ($categories as $category)
{
echo "<option value='" . $category->cat_id ."'>" . $category->cat_desc."</option>";
}
echo "</select>";
echo"<br/><br/>
    <br><br><br>
    <input type='submit' name='btnSaveChanges' value='Save Changes' class='buttonLogin'><br>
    <input type='submit' name='btnHome' value='Home' class='buttonCancel'><br>";

?>
        </div>
        </div>
    </body>
</html>
</div>
