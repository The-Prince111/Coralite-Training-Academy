<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="../Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Admin Portal</title>
    </head>
    <body>
<?php
 include 'AHeader.php';
?>
        <div class="mcontent">
           Admin Home
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>