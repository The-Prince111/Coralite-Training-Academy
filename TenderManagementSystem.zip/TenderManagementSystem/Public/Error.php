<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="../Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Tender Coporation</title>
    </head>
    <body>
<?php
session_start();
 echo "Input Validation Error";
 echo "       <div class='content'>
              <div class='login'>
  <form action='' method='post'>
  <div class='otherhead'>ERRORS</div><br> ";

 echo " <input type='submit' name='btnBack' class'buttonRegister' value='Back'> ";
 echo " <input type=hidden name=controller value='".$_SESSION['controller']."'> ";
 echo " <input type=hidden name=action value='".$_SESSION['action']."'> ";
 echo " <br>
    <br>
</form> 
          </div>
        </div>
include 'Footer.php'; ";
?>
    </body>
</html>
</div>