<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Login</title>
    </head>
    <body>
        <br><br><br><br><br><br><br><br><br>
  <div class="content">   
  <div class="login">
      <form name="login" method="post" >
  <div class="otherhead">LOGIN HERE</div><br>
      <?php
    if(isset($_POST['username']))
    { 
        $uname = $_POST['username'];
        echo "Username<br>";
       echo"   <input type='text' name='username' required value='$uname' class='textbox'><br>";
        
    }
    else
    {
        echo "  Username<br>
  <input type='text' name='username' required  class='textbox'><br>";
    }
    ?>

  Password<br>
  <input type="password" name="password" required class="textbox"><br><br>
  
  <input type="checkbox" name="remMe" value="RemeberMe"> Remember me<br><br>
  <input type="submit" name="btnNew" class="buttonRegister" value="Create New Account">
  <input type=hidden name=controller value=Index>
  <input type=hidden name=action value=login>
  <input type="submit" name="btnLogin" class="buttonLogin" value="login" ><br>
  <input type="submit" name="btnHome" class="buttonCancel" value="Home"><br>
  <br>
  <br>
    <?php
    if(!$error_found.length > 0)
    {
        echo "<p style='color:red'>$error_found</p>";
        
    }
    else
    {
        echo "<p style='color:green'> </p>";
    }
    ?>
</form> 
          </div>
</div>

    </body>
</html>
</div>