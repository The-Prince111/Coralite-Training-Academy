<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Header</title>
    </head>
    <body>
        <div class="header">
         <div class="inheaderleft"></div>   
         <div class="inheaderright">
             <div class="menu">
    <ul>
      <li><a href="?controller=Index&action=index">Home</a></li>
      <li><a href="?controller=Index&action=contact">Contact Support Personnel</a></li>
      <li><a href="?controller=Index&action=about">About Us</a></li>
     <li><a href="?controller=Index&action=opentenders">Open Tenders</a></li>
      <li><a href="?controller=Index&action=login">Login</a></li>
      <li><a href="?controller=Index&action=register">Register</a></li>
    </ul> 
                 
             </div>
         </div>  
        </div>
        <div class="clear"></div>
</body>
</html>
