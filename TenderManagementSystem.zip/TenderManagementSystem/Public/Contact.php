<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Contact Tender Coporation Team</title>
    </head>
    <body>
<?php
 include 'Header.php';
?>
        <div class="mcontent">
            Get assistence from the Tender Coporation team throught email, istant call & messages
        </div>
<?php
include 'Footer.php';
?>
    </body>
</html>
</div>
