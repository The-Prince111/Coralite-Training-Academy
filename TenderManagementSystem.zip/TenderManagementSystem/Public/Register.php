<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="body">
<html>
    <head>
        <meta charset="UTF-8">
        <link href="Lib/home.css" rel="stylesheet" type="text/css"/>
        <title>Register</title>
    </head>
    <body>
        <br>
        <div class="content">
          <div class="reg">
              
<form action="" method="post">
    <div class="otherhead">REGISTER HERE</div>
          <?php
    if(isset($_POST['username']))
    { 
        $uname = $_POST['username'];
        echo "Username<br>";
       echo"   <input type='text' name='username' required value='$uname' class='textbox'><br>";
        
    }
    else
    {
        echo "  Username<br>
  <input type='text' name='username' required  class='textbox'><br>";
    }
    
    if(isset($_POST['password']))
    { 
        $pwd = $_POST['password'];
        echo "Password<br>";
       echo"   <input type='password' name='password' required value='$pwd' class='textbox'><br>";
        
    }
    else
    {
        echo "  Password<br>
  <input type='password' name='password' required  class='textbox'><br>";
    }
    
        if(isset($_POST['confirmpassword']))
    { 
        $cpwd = $_POST['confirmpassword'];
        echo "Confirm Password<br>";
       echo"   <input type='password' name='confirmpassword' required value='$cpwd' class='textbox'><br>";
        
    }
    else
    {
        echo "  Confirm Password<br>
  <input type='password' name='confirmpassword' required  class='textbox'><br>";
    }
    
        if(isset($_POST['surname']))
    { 
        $sname = $_POST['surname'];
        echo "Surname<br>";
       echo"   <input type='text' name='surname' required value='$sname' class='textbox'><br>";
        
    }
    else
    {
        echo "  Surname<br>
  <input type='text' name='surname' required  class='textbox'><br>";
    }
    
        if(isset($_POST['fullname']))
    { 
        $fname = $_POST['fullname'];
        echo "Fullnames<br>";
       echo"   <input type='text' name='fullname' required value='$fname' class='textbox'><br>";
        
    }
    else
    {
        echo "  Fullnames<br>
  <input type='text' name='fullname' required  class='textbox'><br>";
    }
    
        if(isset($_POST['gender']))
    { 
        $gender = $_POST['gender'];
           echo "    <input type='radio' name='gender' value='male' required > Male
  <input type='radio' name='gender' value='female'> Female<br>";
        
    }
    else
    {
        echo "    <input type='radio' name='gender' value='male' required > Male
  <input type='radio' name='gender' value='female'> Female<br>";
    }
    
        if(isset($_POST['idNo']))
    { 
        $id = $_POST['idNo'];
        echo "ID No.<br>";
     
        echo"   <input type='text' name='idNo' required value='$id' class='textbox'><br>";
        
    }
    else
    {
        echo "  ID No.<br>
  <input type='text' name='idNo' required  class='textbox'><br>";
    }
    
        if(isset($_POST['email']))
    { 
        $email = $_POST['email'];
        echo "Email<br>";
       echo"   <input type='email' name='email' required value='$email' class='textbox'><br>";
        
    }
    else
    {
        echo "  Email<br>
  <input type='text' name='email' required  class='textbox'><br>";
    }
    
        if(isset($_POST['cell']))
    { 
        $cell = $_POST['cell'];
        echo "Cell<br>";
       echo"   <input type='text' name='cell' required value='$cell' class='textbox'><br>";
        
    }
    else
    {
        echo "  Cell<br>
  <input type='number' name='cell' required  class='textbox'><br>";
    }
    
        if(isset($_POST['tell']))
    { 
        $tell = $_POST['tell'];
        echo "Tell<br>";
       echo"   <input type='number' name='tell' required value='$tell' class='textbox'><br>";
        
    }
    else
    {
        echo "  Tell<br>
  <input type='number' name='tell' required  class='textbox'><br>";
    }
    
        if(isset($_POST['role']))
    { 
        $role = $_POST['role'];
       echo"     <input type='radio' name='role'value='Client' required> Client
  <input type='radio' name='role' value='Manager' > Manager<br>";
        
    }
    else
    {
       echo"     <input type='radio' name='role'value='Client' required> Client
  <input type='radio' name='role' value='Manager' > Manager<br>";
    }
    ?>
  <br>
      <input type=hidden name=controller value='Index'>
       <input type=hidden name=action value='register'>
        <button type="submit" name="btnRegister" class="buttonLogin" value="Submit">Register</button><br>
        <button type="submit" name="btnHome" class="buttonCancel" value="Home">Home</button><br>
            <?php
    if(!$error_found.length > 0)
    {
        echo "<p style='color:red'>$error_found</p>";
        
    }
    else
    {
        echo "<p style='color:green'> </p>";
    }
    ?>
</form>

            </div>
        </div>

    </body>
</html>
</div>